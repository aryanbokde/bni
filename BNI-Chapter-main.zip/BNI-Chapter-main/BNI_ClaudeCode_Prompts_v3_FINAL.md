# BNI Chapter Engagement Platform
## Claude Code Prompt Playbook
### Stack: Next.js 14 · MySQL 8 · PWA · Prisma · Tailwind · TypeScript
### WhatsApp: Meta Cloud API (direct) · Auth: Email + Password · v3 — Final

---

## EDITION NOTES — v3 Final

| Change | Detail |
|---|---|
| Auth | **Email + Password** — no OTP, no WhatsApp auth, no phone verification. Standard bcrypt login. |
| WhatsApp | **Meta Cloud API (direct)** for 1-2-1 recommendation messages ONLY — not involved in auth. |
| Meta templates | **One template only**: `bni_121_introduction`. No `bni_otp` template needed. |
| DB — members | `email` is now required. Added `email_hash` (login lookup) and `password_hash` (bcrypt). |
| DB — removed | `otp_requests` table removed entirely. |
| Env vars | `WHATSAPP_OTP_TEMPLATE_NAME` removed. Auth env vars are standard JWT secrets only. |
| Token storage | Access token: in-memory React state. Refresh token: HttpOnly cookie. Auto-refresh on app load. |
| Rate limiting | Login endpoint: 5 attempts per 15 min per IP via express-rate-limit equivalent in Next.js. |
| First admin | Seed creates admin with default password `BNI@2026!` — must be changed on first login. |
| Everything else | DB schema, PWA, Google Maps, recommendations, deployment — all unchanged from v2. |

---

## HOW TO USE THIS PLAYBOOK

1. Open your project folder in VS Code
2. Open Claude Code (sidebar or `Ctrl+Shift+P → Claude Code`)
3. Copy one prompt at a time — paste it into Claude Code — let it finish completely before moving to the next
4. After every module run the **TEST** prompt, then the **FIX** prompt
5. Never skip a phase — each one builds on the previous
6. If Claude Code asks a clarifying question, answer it before continuing

> **Vibe Coder Rule:** If something looks wrong after a prompt, paste the error message directly into Claude Code and say _"fix this error"_. Don't edit code manually unless instructed.

---

## SRS ADDENDUM — PWA-Specific Requirements
*(These additions apply on top of SRS v1.0 Lean Edition)*

| Requirement | Detail |
|---|---|
| Installable | App must be installable on Android and iOS home screen via PWA. No App Store submission needed. |
| Offline — Member List | Last-fetched member list must be readable offline (NetworkFirst cache, 5-min TTL) |
| Offline — Own Profile | Member's own profile page must load offline (cached after first visit) |
| Offline — Map Tiles | Google Maps tiles cached for 7 days so the chapter map is usable in low-connectivity venues |
| Offline Fallback | Custom branded offline.html shown when an uncached page is requested without connectivity |
| Install Prompt | A bottom-sheet install banner appears on first visit on mobile. Dismissed state persisted in localStorage. |
| App Shortcuts | Manifest shortcuts: "Member Directory" → /chapter/members, "Engagement Matrix" → /chapter/matrix |
| No Service Worker in Dev | PWA disabled in development (NODE_ENV !== production) to avoid caching confusion |
| Push Notifications | Architecture must be push-notification-ready (VAPID keys generated) but not yet wired to UI — deferred to v2 |
| WhatsApp Channel | Meta WhatsApp Cloud API (direct) — no third-party middleware. Free tier: 1,000 conversations/month. Template category: Utility. |

---

## PHASE 0 — PROJECT BOOTSTRAP

---

### P00-01 · Initialize Next.js Project

```
Create a new Next.js 14 project with the App Router in the current folder. Use these exact settings:

- Framework: Next.js 14
- Language: TypeScript (strict mode)
- Styling: Tailwind CSS
- App Router: yes
- src/ directory: yes
- Import alias: @/*

After scaffolding, install these additional packages:
  npm install prisma @prisma/client
  npm install next-pwa
  npm install node-cron @types/node-cron
  npm install jsonwebtoken @types/jsonwebtoken bcryptjs @types/bcryptjs
  npm install uuid @types/uuid
  npm install zod
  npm install @tanstack/react-query
  npm install nodemailer @types/nodemailer
  npm install axios
  npm install date-fns
  npm install exceljs

Then run: npx prisma init --datasource-provider mysql

Show me the final package.json so I can confirm all packages are installed.
```

---

### P00-02 · Project Folder Structure

```
Create the following folder structure inside src/. Create empty index.ts or .gitkeep files as needed so the folders exist:

src/
  app/
    (auth)/
      login/
    (dashboard)/
      chapter/
        members/
          [memberId]/
          new/
        matrix/
        map/
        recommendations/
        settings/
        audit/
    api/
      auth/
        otp/
          request/
          verify/
        refresh/
        logout/
      chapters/
        [chapterId]/
          members/
            [memberId]/
              archive/
              restore/
          settings/
          shareable-fields/
          matrix/
            member/
              [memberId]/
          recommendations/
            run/
            manual/
            [recId]/
              complete/
              exclude/
              reinstate/
          map/
            members/
            member/
              [memberId]/
          audit-logs/
      webhooks/
        whatsapp/
  lib/
  services/
  adapters/
  jobs/
  components/
    ui/
    matrix/
    map/
    members/
    recommendations/
  types/
  hooks/

Also create these root-level files (empty for now):
  server.js
  ecosystem.config.js
  public/manifest.json
  public/offline.html
  public/icons/.gitkeep
```

---

### P00-03 · Environment Setup

```
Create a .env.local file with all required environment variables for this project. Also create a .env.example file (same keys, fake values) and add .env.local to .gitignore.

Use these exact variable names:

# Database
DATABASE_URL="mysql://bni_user:password@localhost:3306/bnidb"

# Auth
JWT_SECRET="replace-with-64-char-random-hex"
REFRESH_TOKEN_SECRET="replace-with-64-char-random-hex"

# PII Encryption
ENCRYPTION_KEY="replace-with-64-char-hex-32-bytes-for-aes256"
HASH_PEPPER="replace-with-32-char-random-string"

# WhatsApp — Meta Cloud API (direct)
WHATSAPP_PROVIDER="meta"
WHATSAPP_PHONE_NUMBER_ID="your-15-digit-phone-number-id"
WHATSAPP_BUSINESS_ACCOUNT_ID="your-waba-id"
WHATSAPP_API_TOKEN="your-permanent-system-user-token"
WHATSAPP_VERIFY_TOKEN="bni-webhook-verify-2026"
WHATSAPP_TEMPLATE_NAME="bni_121_introduction"

# Google Maps
NEXT_PUBLIC_GOOGLE_MAPS_KEY="your-frontend-maps-key"
GOOGLE_MAPS_SERVER_KEY="your-server-geocoding-key"

# App
NODE_ENV="development"
PORT="3000"
NEXT_PUBLIC_APP_URL="http://localhost:3000"

Then create src/lib/env.ts that uses zod to validate all required env vars at startup and throws a clear error if any are missing. Export typed env object from this file.

Also add to env.ts validation:
- WHATSAPP_OTP_TEMPLATE_NAME should NOT be present — if someone adds it by mistake, log a warning: "WHATSAPP_OTP_TEMPLATE_NAME is not used in this version. Auth uses email+password."
- Validate email-related vars are NOT present that would suggest OTP confusion
```

---

### P00-04 · next.config.js — PWA + Custom Server

```
Replace next.config.js with a full configuration that:

1. Wraps the config with next-pwa:
   - dest: 'public'
   - register: true
   - skipWaiting: true
   - disable when NODE_ENV === 'development'
   - Runtime caching rules:
       a) Google Maps tiles: urlPattern /maps\.googleapis\.com/, CacheFirst, 7 days, max 200 entries, cacheName 'google-maps'
       b) Member list API: urlPattern /\/api\/.*\/members/, NetworkFirst, networkTimeoutSeconds: 10, maxAgeSeconds: 300 (5 min), cacheName 'api-members'
       c) Static assets (png, jpg, css, js, woff2): CacheFirst, 30 days, max 200 entries, cacheName 'static-assets'
   - fallbacks: { document: '/offline.html' }

2. Standard Next.js config:
   - images: remotePatterns for maps.googleapis.com
   - typescript: ignoreBuildErrors false
   - eslint: ignoreDuringBuilds false

Show me the complete next.config.js file.
```

---

### P00-05 · PWA Static Assets

```
Do the following:

1. Create public/manifest.json with:
{
  "name": "BNI Chapter Connect",
  "short_name": "BNI Connect",
  "description": "Chapter engagement, 1-2-1 connections, and member directory",
  "start_url": "/chapter/members",
  "display": "standalone",
  "background_color": "#1B2A4A",
  "theme_color": "#2E75B6",
  "orientation": "portrait-primary",
  "icons": [
    { "src": "/icons/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any maskable" },
    { "src": "/icons/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable" }
  ],
  "shortcuts": [
    { "name": "Member Directory", "url": "/chapter/members", "icons": [{"src": "/icons/icon-192.png", "sizes": "96x96"}] },
    { "name": "Engagement Matrix", "url": "/chapter/matrix", "icons": [{"src": "/icons/icon-192.png", "sizes": "96x96"}] }
  ]
}

2. Create public/offline.html — a clean branded offline page with:
   - Dark navy background (#1B2A4A), white text
   - "BNI Connect" heading in blue (#2E75B6)
   - Message: "You are offline. Your member list is still available from cache."
   - A "Try Again" button that calls location.reload()
   - No external dependencies — pure inline HTML/CSS

3. Create a placeholder SVG for public/icons/map-pin.svg — a simple blue teardrop map pin shape in #2E75B6
```

---

### P00-06 · Tailwind + Global Styles + Root Layout

```
1. Update tailwind.config.ts to add these custom colors to the theme:
   navy: '#1B2A4A'
   'bni-blue': '#2E75B6'
   teal: '#007A6E'
   bni-green: '#2E7D32'
   bni-amber: '#E65100'
   bni-red: '#B71C1C'

2. Update src/app/globals.css with base Tailwind directives and:
   - Custom utility class .card for card containers (white bg, rounded-xl, shadow-md, p-4)
   - Custom utility class .btn-primary (navy bg, white text, rounded-lg, px-4 py-2, hover transition)
   - Custom utility class .btn-secondary (border navy, navy text, rounded-lg, px-4 py-2)
   - Font: Inter from Google Fonts

3. Create src/app/layout.tsx as the root layout with:
   - HTML lang="en"
   - Inter font
   - All PWA meta tags: theme-color, apple-mobile-web-app-capable, apple-mobile-web-app-status-bar-style, apple-touch-icon, viewport
   - Link to /manifest.json
   - ReactQueryProvider wrapper (create src/lib/QueryProvider.tsx as a 'use client' component)
   - Google Maps Script tag loaded with strategy='afterInteractive' using NEXT_PUBLIC_GOOGLE_MAPS_KEY with libraries=places
   - The InstallPrompt component (create it as a placeholder 'use client' component for now — we'll fill it later)
   - Full metadata export for PWA
```

---

### TEST-P00 · Bootstrap Verification

```
Run these checks and fix anything that fails:

1. Run: npm run dev
   Confirm the dev server starts on port 3000 with no TypeScript errors.

2. Run: npx tsc --noEmit
   Fix all TypeScript errors before continuing.

3. Run: npx prisma validate
   Confirm Prisma schema is valid (it should just have the datasource block for now).

4. Check that src/lib/env.ts throws a readable error when DATABASE_URL is missing by temporarily removing it from .env.local, running npm run dev, checking the error, then restoring the variable.

5. Open http://localhost:3000 in a browser. You should see the default Next.js page with no console errors.

Report what you find and fix any issues.
```

---

### FIX-P00 · Bootstrap Bug Fix

```
Review all files created in Phase 0. Check for:
- TypeScript type errors
- Missing imports or exports
- next.config.js configuration issues (test by running npm run build in dry-run)
- Any file that imports from a path that doesn't exist yet

Fix all issues found. Run npm run dev again to confirm a clean start.
```

---

## PHASE 1 — DATABASE SCHEMA (MySQL + Prisma)

---

### P01-01 · Prisma Schema — All Models

```
Replace the contents of prisma/schema.prisma with the complete schema for the BNI platform.

datasource: mysql, url from env DATABASE_URL
generator: prisma-client-js

Create these models with exact field names, types, and relations:

MODEL chapters:
  chapter_id              String    @id @default(uuid()) @db.Char(36)
  chapter_name            String    @db.VarChar(150)
  meeting_day             Int       @db.TinyInt  (0=Sun..6=Sat)
  meeting_start_time      String    @db.VarChar(8)  (stored as "07:00:00")
  meeting_duration_mins   Int       @default(90)
  timezone                String    @default("Asia/Kolkata") @db.VarChar(60)
  quiet_start             String    @default("21:00") @db.VarChar(5)
  quiet_end               String    @default("07:00") @db.VarChar(5)
  rsvp_reminder_schedule  Json      (default: [{"offset_day":-1,"time":"19:00"},{"offset_day":0,"time":"06:00"}])
  lookback_days           Int       @default(180)
  cooldown_days           Int       @default(60)
  max_recs_per_cycle      Int       @default(3)
  post_meeting_delay_mins Int       @default(120)
  rec_expiry_days         Int       @default(30)
  office_lat              Float?
  office_lng              Float?
  location_display_mode   String    @default("AREA_ONLY") @db.VarChar(20)
  created_at              DateTime  @default(now()) @db.DateTime
  updated_at              DateTime  @updatedAt @db.DateTime
  members                 members[]
  shareable_fields        shareable_fields[]
  recommendations         recommendations[]
  recommendation_runs     recommendation_runs[]
  member_interactions     member_interactions[]

MODEL members:
  member_id        String   @id @default(uuid()) @db.Char(36)
  chapter_id       String   @db.Char(36)
  full_name        String   @db.VarChar(150)
  -- Contact fields (all still needed for WhatsApp recommendation messages)
  mobile_enc       Bytes               (encrypted AES-256-GCM)
  mobile_hash      String   @db.Char(64)
  whatsapp_enc     Bytes               (encrypted)
  whatsapp_hash    String   @db.Char(64)

  -- Auth fields (email is required — it is the login identifier)
  email_enc        Bytes               (encrypted — NOT nullable. Email required for login.)
  email_hash       String   @db.Char(64)  (SHA-256+pepper for UNIQUE login lookup)
  password_hash    String?  @db.VarChar(60)  (bcrypt hash — null until Admin sets it)
  biz_category     String   @db.VarChar(100)
  one_line_summary String   @db.VarChar(250)
  intro_text       String?  @db.VarChar(400)
  office_address   String   @db.Text
  latitude         Float?
  longitude        Float?
  geocode_status   String   @default("PENDING") @db.VarChar(20)
  status           String   @default("ACTIVE") @db.VarChar(20)
  comm_eligible    Boolean  @default(true)
  rec_active       Boolean  @default(true)
  chapter_role     String   @default("MEMBER") @db.VarChar(30)
  joining_date     DateTime @db.Date
  created_at       DateTime @default(now()) @db.DateTime
  updated_at       DateTime @updatedAt @db.DateTime
  created_by       String?  @db.Char(36)
  updated_by       String?  @db.Char(36)
  chapter          chapters @relation(fields:[chapter_id], references:[chapter_id])
  @@unique([chapter_id, mobile_hash])
  @@unique([chapter_id, whatsapp_hash])
  @@unique([chapter_id, email_hash])
  @@index([chapter_id, status])
  @@index([chapter_id, chapter_role])

MODEL shareable_fields:
  chapter_id    String   @db.Char(36)
  field_name    String   @db.VarChar(50)
  is_shareable  Boolean  @default(false)
  updated_at    DateTime @updatedAt @db.DateTime
  updated_by    String?  @db.Char(36)
  chapter       chapters @relation(...)
  @@id([chapter_id, field_name])

MODEL member_interactions:
  interaction_id   String   @id @default(uuid()) @db.Char(36)
  chapter_id       String   @db.Char(36)
  member_a_id      String   @db.Char(36)
  member_b_id      String   @db.Char(36)
  interaction_date DateTime @db.Date
  source           String   @db.VarChar(30)
  confirmed_by     String?  @db.Char(36)
  notes            String?  @db.Text
  rec_id           String?  @db.Char(36)
  created_at       DateTime @default(now()) @db.DateTime
  chapter          chapters @relation(...)
  @@unique([member_a_id, member_b_id, interaction_date])
  @@index([member_a_id, interaction_date(sort: Desc)])
  @@index([member_b_id, interaction_date(sort: Desc)])
  @@index([chapter_id, interaction_date(sort: Desc)])

MODEL recommendations:
  rec_id          String   @id @default(uuid()) @db.Char(36)
  chapter_id      String   @db.Char(36)
  member_a_id     String   @db.Char(36)
  member_b_id     String   @db.Char(36)
  run_id          String?  @db.Char(36)
  status          String   @default("QUEUED") @db.VarChar(20)
  sent_at         DateTime?
  completed_at    DateTime?
  expired_at      DateTime?
  excluded_at     DateTime?
  excluded_by     String?  @db.Char(36)
  excluded_reason String?  @db.Text
  wa_msg_id_a     String?  @db.VarChar(100)
  wa_msg_id_b     String?  @db.VarChar(100)
  send_attempts   Int      @default(0)
  created_at      DateTime @default(now()) @db.DateTime
  updated_at      DateTime @updatedAt @db.DateTime
  chapter         chapters @relation(...)
  @@index([chapter_id, status])
  @@index([member_a_id, status])
  @@index([member_b_id, status])

MODEL recommendation_runs:
  run_id          String   @id @default(uuid()) @db.Char(36)
  chapter_id      String   @db.Char(36)
  trigger_type    String   @db.VarChar(20)
  meeting_id      String?  @db.Char(36)
  started_at      DateTime @default(now()) @db.DateTime
  completed_at    DateTime?
  status          String   @default("RUNNING") @db.VarChar(20)
  pairs_evaluated Int      @default(0)
  pairs_sent      Int      @default(0)
  pairs_skipped   Int      @default(0)
  error_detail    String?  @db.Text
  chapter         chapters @relation(...)

MODEL audit_logs:
  log_id      BigInt   @id @default(autoincrement())
  entity_type String   @db.VarChar(50)
  entity_id   String   @db.Char(36)
  operation   String   @db.VarChar(20)
  field_name  String?  @db.VarChar(80)
  old_value   String?  @db.Text
  new_value   String?  @db.Text
  actor_id    String   @db.Char(36)
  actor_role  String   @db.VarChar(30)
  source      String   @db.VarChar(20)
  occurred_at DateTime @default(now()) @db.DateTime
  @@index([entity_type, entity_id])
  @@index([actor_id])

MODEL refresh_tokens:
  id          String   @id @default(uuid()) @db.Char(36)
  member_id   String   @db.Char(36)
  token_hash  String   @db.Char(64)
  expires_at  DateTime @db.DateTime
  created_at  DateTime @default(now()) @db.DateTime
  is_revoked  Boolean  @default(false)
  @@index([token_hash])
  @@index([member_id])

-- otp_requests: REMOVED. Auth uses email+password. No OTP table needed.

After writing the schema, run:
  npx prisma format
  npx prisma validate

Show me confirmation that both commands pass.
```

---

### P01-02 · Database Migration & Seed

```
Do the following in order:

1. Make sure MySQL is running locally and a database named 'bnidb' exists. Run:
   mysql -u root -p -e "CREATE DATABASE IF NOT EXISTS bnidb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

2. Run the first migration:
   npx prisma migrate dev --name init_all_tables

3. Create prisma/seed.ts that:
   a) Creates one demo chapter named "Ahmedabad Central" with:
      - meeting_day: 4 (Thursday)
      - meeting_start_time: "07:00:00"
      - meeting_duration_mins: 90
      - timezone: "Asia/Kolkata"
      - lookback_days: 180
      - cooldown_days: 60
      - max_recs_per_cycle: 3
   
   b) Seeds shareable_fields for this chapter with these fields and their defaults:
      - full_name: true
      - biz_category: true
      - one_line_summary: true
      - intro_text: false
      - whatsapp: true
      - office_address: false (uses area-only mode)

   c) Creates one demo Admin member for this chapter using real crypto from src/lib/crypto.ts:
      - full_name: "Chapter Admin"
      - chapter_role: "ADMIN"
      - status: "ACTIVE"
      - email: "admin@bnichapter.com" (encrypted + hashed)
      - mobile: "+910000000000" (encrypted + hashed — placeholder)
      - whatsapp: "+910000000000" (encrypted + hashed — placeholder)
      - password_hash: bcrypt.hashSync("BNI@2026!", 10)
      
      IMPORTANT: Log this message at the end of seed:
      console.log("\n=== FIRST LOGIN ===");
      console.log("Email:    admin@bnichapter.com");
      console.log("Password: BNI@2026!");
      console.log("Change this password immediately after first login!\n");

4. Add seed script to package.json:
   "prisma": { "seed": "ts-node --compiler-options {\"module\":\"CommonJS\"} prisma/seed.ts" }

5. Install ts-node if not present: npm install -D ts-node

6. Run: npx prisma db seed

7. Create src/lib/db.ts — Prisma client singleton:
   - Export a single PrismaClient instance
   - Use global variable pattern to prevent multiple instances in Next.js dev hot-reload
   - Log queries only in development

Show me the output of each step.
```

---

### TEST-P01 · Database Tests

```
Create src/__tests__/database.test.ts using Jest (install Jest if not present: npm install -D jest @types/jest ts-jest).

Create jest.config.ts with ts-jest configuration.

Write these test cases:
1. Test that PrismaClient connects to MySQL successfully
2. Test that the demo chapter exists after seeding
3. Test that shareable_fields are seeded correctly (6 fields for the demo chapter)
4. Test that the UNIQUE constraint on (chapter_id, mobile_hash) is enforced — attempt to insert a duplicate and expect an error
5. Test that member_interactions CHECK constraint (member_a_id < member_b_id) is enforced

Run: npm test -- --testPathPattern=database

Fix any failures before continuing.
```

---

### FIX-P01 · Database Bug Fix

```
Check the Prisma schema and migration for these common MySQL issues:
1. Ensure all @db.Char(36) UUIDs are consistent — no mix of VarChar and Char for the same relationship
2. Verify all foreign key relations are correct and Prisma can generate the client without errors
3. Run: npx prisma generate — confirm it completes with no errors
4. Run: npx prisma studio — open it briefly to confirm all tables are visible, then close it
5. Check prisma/seed.ts for TypeScript errors

Fix anything found. Run npx prisma migrate status and confirm all migrations are applied.
```

---

## PHASE 2 — CORE INFRASTRUCTURE

---

### P02-01 · PII Encryption Utilities

```
Create src/lib/crypto.ts with these exported functions:

1. encrypt(plaintext: string): Buffer
   - Uses AES-256-GCM
   - 12-byte random IV prepended to output
   - 16-byte auth tag appended after IV
   - Format: iv(12 bytes) + tag(16 bytes) + ciphertext
   - Uses ENCRYPTION_KEY from env (32 bytes, passed as hex string)

2. decrypt(data: Buffer): string
   - Reverses the above format
   - Throws if auth tag verification fails

3. hashPhone(phone: string): string
   - Normalises phone: removes spaces, strips all non-digits except leading +
   - Creates SHA-256 HMAC using HASH_PEPPER as key
   - Returns hex string
   - Used for UNIQUE lookup of mobile_hash and whatsapp_hash

4. normalisePhone(phone: string): string
   - Strips all non-digit characters except leading +
   - Returns cleaned phone string

5. hashEmail(email: string): string
   - Normalise: trim + toLowerCase
   - Creates SHA-256 HMAC using HASH_PEPPER as key
   - Returns hex string
   - Used for UNIQUE login lookup (email_hash column)

6. normaliseEmail(email: string): string
   - trim().toLowerCase()
   - Returns cleaned email string

Write unit tests in src/__tests__/crypto.test.ts:
- Test encrypt → decrypt round-trip returns original string
- Test that two encryptions of the same string produce different ciphertexts (IV is random)
- Test that decrypt throws on tampered ciphertext
- Test hashPhone: same input always returns same hash
- Test hashPhone: different inputs return different hashes
- Test hashEmail: "User@Example.com" and "user@example.com" return the same hash (case-insensitive)
- Test hashEmail: different emails return different hashes
- Test normaliseEmail: trims whitespace and lowercases

Run the tests and fix any failures.
```

---

### P02-02 · JWT Authentication Utilities

```
Create src/lib/auth.ts with:

1. Type: AuthContext { memberId: string; chapterId: string; role: string }

   IMPORTANT — chapter_id in JWT:
   The JWT payload always includes chapterId from the member record.
   This means every authenticated API call knows which chapter the user belongs to.
   API routes use params.chapterId (from the URL) and verify it matches actor.chapterId
   before processing any request. A member from Chapter A cannot access Chapter B's data.
   This is enforced in every route handler — not just middleware.

2. signAccessToken(payload: AuthContext): string
   - Signs with JWT_SECRET
   - Expiry: 15 minutes
   - Algorithm: HS256
   - Includes iat and exp

3. signRefreshToken(): string
   - Generates 64 random bytes as hex string
   - This is the raw token (stored hashed in DB)

4. verifyAccessToken(token: string): AuthContext
   - Throws AppError('TOKEN_EXPIRED', 401) if expired
   - Throws AppError('UNAUTHENTICATED', 401) if invalid

5. hashRefreshToken(token: string): string
   - SHA-256 hash of the raw token for DB storage

6. requireAuth(req: Request): Promise<AuthContext>
   - Reads Authorization header
   - Calls verifyAccessToken
   - Returns AuthContext

7. requireRole(actor: AuthContext, allowed: string[]): void
   - Throws AppError('FORBIDDEN', 403) if role not in allowed

8. TOKEN STORAGE STRATEGY — Critical security decision:
   Access token (15 min JWT):
   - Stored in MEMORY only — React state/context (not localStorage, not sessionStorage)
   - Why: localStorage is accessible to any JS on the page (XSS risk)
   - Consequence: lost on page refresh — handled by auto-refresh below

   Refresh token (7 day):
   - Stored in HttpOnly Secure SameSite=Strict cookie
   - Not accessible to JavaScript at all
   - Sent automatically by browser on refresh requests

   Auto-refresh on app load:
   - Create src/lib/TokenProvider.tsx ('use client')
   - On mount: call POST /api/auth/refresh (sends cookie automatically)
   - If success: store new access token in React context
   - If fail (cookie expired/missing): redirect to /login
   - Wrap entire app in TokenProvider inside layout.tsx
   - All API calls read access token from context and add Authorization header

   Create src/hooks/useApi.ts:
   - Returns an axios instance with the current access token in Authorization header
   - On 401 response: attempt one token refresh, retry original request
   - If refresh also fails: clear token context, redirect to /login
   - Import this hook in all components that make API calls

Create src/lib/AppError.ts:
- export class AppError extends Error
- constructor(code: string, httpStatus: number, fields?: Record<string,string>)
- Include code and httpStatus as public properties

Create src/lib/apiResponse.ts:
- ok(data: unknown, meta?: object): NextResponse — status 200
- created(data: unknown): NextResponse — status 201
- noContent(): NextResponse — status 204
- apiError(error: AppError): NextResponse — formats {error:{code,message,fields}}
- withErrorHandling(handler): wrapped route handler that catches AppError and unknown errors

Write tests for signAccessToken, verifyAccessToken (valid, expired, tampered).
```

---

### P02-03 · Email + Password Auth

```
Implement email + password authentication. WhatsApp is NOT involved in auth.

1. Create src/services/AuthService.ts:

   login(email: string, password: string)
     : Promise<{ accessToken: string; refreshToken: string; member: MemberDecrypted }>
     1. normaliseEmail(email) — trim + toLowerCase
     2. hashEmail(email) → email_hash
     3. Find member WHERE email_hash = ? AND status = 'ACTIVE'
     4. ALWAYS throw AppError('INVALID_CREDENTIALS', 401) for ANY failure below
        (never reveal whether email exists — prevents enumeration attacks)
     5. Check failed_login_attempts < 5. If >= 5 AND locked_until > NOW():
        throw AppError('ACCOUNT_LOCKED', 401, { message: 'Too many failed attempts. Try again in 15 minutes.' })
     6. If member not found: increment attempt counter (on a temp table), throw INVALID_CREDENTIALS
     7. If password_hash is null: throw AppError('PASSWORD_NOT_SET', 401,
        { message: 'Contact your Chapter Admin to activate your account.' })
     8. bcrypt.compare(password, member.password_hash)
     9. If false: increment member.failed_login_attempts + update member.locked_until if attempts >= 5
        Then throw INVALID_CREDENTIALS
     10. On success: reset failed_login_attempts=0, locked_until=null
     11. signAccessToken({ memberId, chapterId: member.chapter_id, role: member.chapter_role })
     12. signRefreshToken() → raw token
     13. hashRefreshToken(raw) → hash, INSERT into refresh_tokens
     14. Write audit log: operation='LOGIN', entity_type='members'
     15. Return { accessToken, refreshToken: raw, member: decrypted }

   setPassword(memberId: string, newPassword: string, actorId: string, actorRole: string): Promise<void>
     1. If actorRole !== 'ADMIN' AND actorId !== memberId: throw FORBIDDEN
     2. Validate: newPassword.length >= 8, contains at least one letter and one number
        If invalid: throw AppError('WEAK_PASSWORD', 422,
          { password: 'Minimum 8 characters with at least one letter and one number' })
     3. bcrypt.hash(newPassword, 10) → password_hash
     4. UPDATE member: password_hash, reset failed_login_attempts=0, locked_until=null
     5. Write audit log: operation='UPDATE', field_name='password_hash',
        old_value='[REDACTED]', new_value='[REDACTED]'
        — NEVER log actual password values

   resetPassword(memberId: string, tempPassword: string, actorId: string): Promise<void>
     — ADMIN only. Calls setPassword internally.
     — Admin communicates the temp password to member out-of-band (call or in-person)

   refreshTokens(rawRefreshToken: string): Promise<{ accessToken: string; refreshToken: string }>
     1. hashRefreshToken(raw) → hash
     2. Find refresh_tokens WHERE token_hash=hash AND is_revoked=false AND expires_at > NOW()
     3. If not found: throw AppError('INVALID_REFRESH_TOKEN', 401)
     4. Revoke old token (UPDATE is_revoked=true)
     5. Load member to get current role (role may have changed since last login)
     6. Generate new access token + new refresh token
     7. Store new refresh token hash
     8. Return both

   logout(rawRefreshToken: string): Promise<void>
     1. hashRefreshToken(raw) → hash
     2. UPDATE refresh_tokens SET is_revoked=true WHERE token_hash=hash
     3. (Fail silently — logout should always succeed from user's perspective)

2. Add to members table migration (create new migration):
   failed_login_attempts  Int       @default(0)
   locked_until           DateTime? @db.DateTime

3. Create API route handlers:

   POST /api/auth/login
   — No auth required
   — Rate limit: 5 requests per 15 minutes per IP (use next-rate-limit or custom middleware)
   — Body: { email: string; password: string }
   — Validate with Zod: email must be valid email format, password non-empty
   — Call AuthService.login
   — On success: set refresh token as HttpOnly cookie:
       res.cookies.set('refresh_token', refreshToken, {
         httpOnly: true, secure: true, sameSite: 'strict',
         maxAge: 60 * 60 * 24 * 7,
         path: '/api/auth/refresh',
       })
   — Return: { data: { accessToken, member } }
   — NEVER return the refresh token in the response body

   POST /api/auth/logout
   — No auth required (member may have expired access token)
   — Read refresh_token cookie
   — Call AuthService.logout
   — Clear cookie: res.cookies.delete('refresh_token')
   — Return 204

   POST /api/auth/refresh
   — No auth required
   — Read refresh_token from cookie (NOT from body or header)
   — Call AuthService.refreshTokens
   — Set new refresh_token cookie (same options as login)
   — Return: { data: { accessToken } }
   — On failure: clear cookie, return 401

   POST /api/auth/set-password
   — requireAuth
   — Body: { memberId: string; newPassword: string }
   — ADMIN: any memberId | MEMBER: own memberId only
   — Call AuthService.setPassword

4. Create src/lib/TokenProvider.tsx ('use client'):
   — React context that holds the access token in state
   — On mount: call POST /api/auth/refresh
   — If success: store accessToken in context state
   — If fail: redirect to /login (cookie expired or never set)
   — Export: useAccessToken() hook returns current token
   — Export: useSetAccessToken() hook to update token after login

5. Create src/hooks/useApi.ts:
   — Returns axios instance pre-configured with:
       baseURL: '/api'
       Authorization header from useAccessToken()
   — Response interceptor:
       On 401: call POST /api/auth/refresh once
       If refresh succeeds: update token context, retry original request
       If refresh fails: redirect to /login
   — All components use this hook for API calls instead of raw fetch

6. Rate limiting — create src/lib/rateLimit.ts:
   — Simple in-memory store (Map<string, { count, resetAt }>)
   — checkRateLimit(key: string, limit: number, windowMs: number): boolean
   — Use in login route: key = req.headers.get('x-forwarded-for') ?? 'unknown'
   — If limit exceeded: throw AppError('RATE_LIMIT_EXCEEDED', 429,
       { message: 'Too many login attempts. Try again in 15 minutes.' })

7. Create src/app/(auth)/login/page.tsx ('use client'):
   — Single form: Email input + Password input (with show/hide toggle) + Login button
   — Zod client-side validation before submit (email format, password non-empty)
   — Calls POST /api/auth/login via fetch (NOT useApi — no token yet)
   — On success: store accessToken via useSetAccessToken(), redirect to /chapter/members
   — Error 'INVALID_CREDENTIALS': show "Invalid email or password" (same msg for both)
   — Error 'PASSWORD_NOT_SET': show "Account not activated. Contact your Chapter Admin."
   — Error 'ACCOUNT_LOCKED': show "Account locked. Try again in 15 minutes."
   — Error 'RATE_LIMIT_EXCEEDED': show "Too many attempts. Try again later."
   — Loading state on button
   — BNI branding: navy background, white card, blue button
   — "Add to Home Screen" PWA hint for mobile users (check standalone mode)
   — Do NOT show "Forgot password" link — Admin resets passwords

8. Add "Change Password" section to member profile page:
   — Form: Current Password + New Password + Confirm New Password
   — Client-side: passwords must match, min 8 chars
   — Calls POST /api/auth/set-password with own memberId
   — Success: show toast "Password changed successfully"

9. Add "Reset Member Password" button to Admin member management:
   — Only visible to ADMIN role
   — Opens modal: enter temp password for the member
   — Calls POST /api/auth/set-password with that member's ID
   — Success: "Temp password set. Share it with [member name] securely."
```

---

### P02-04 · Auth Middleware

```
Create src/lib/cors.ts:
— Next.js App Router handles CORS via response headers
— For API routes, add this helper:
    export function withCors(res: NextResponse): NextResponse {
      res.headers.set('Access-Control-Allow-Origin', process.env.NEXT_PUBLIC_APP_URL!);
      res.headers.set('Access-Control-Allow-Methods', 'GET,POST,PATCH,DELETE,OPTIONS');
      res.headers.set('Access-Control-Allow-Headers', 'Authorization,Content-Type');
      res.headers.set('Access-Control-Allow-Credentials', 'true');
      return res;
    }
— In next.config.js headers section, add headers for API routes restricting to APP_URL
— The app is same-origin (frontend and API on same Next.js server), so CORS only matters
  if you ever call the API from a different domain. Set it up correctly now.

Create src/middleware.ts (Next.js middleware) that:
1. Runs on all routes EXCEPT /login, /api/auth/login, /api/auth/logout, /api/auth/refresh, /api/webhooks/*, /_next/*, /icons/*, /manifest.json, /offline.html, /sw.js, /workbox-*
   Note: /api/auth/set-password DOES require auth — it is NOT in the exempt list
2. Reads Authorization: Bearer <token> header (set by useApi hook on all client requests)
   For Server Component pages that need session: reads from TokenProvider context via cookies
   Note: access token is in-memory on client. For SSR pages, pass data as props from the API directly.
3. If no valid token: redirect to /login for page routes, return 401 JSON for /api routes
4. If valid: let request proceed

Create src/lib/session.ts:
- getServerSession(req?: Request): Promise<AuthContext | null>
  — For Server Components (reads cookies via next/headers)
- getClientSession(): AuthContext | null
  — For Client Components (reads from localStorage — we'll store non-sensitive session data there)

Also create a React context src/lib/SessionContext.tsx ('use client'):
- Provides AuthContext to client components
- Reads from localStorage
- Exposes logout() function that calls POST /api/auth/logout then redirects to /login
```

---

### TEST-P02 · Auth Tests

```
Create src/__tests__/auth.test.ts using real test DB (use beforeAll to seed test member).

Seed data for tests:
  - Test chapter (same seed chapter)
  - Member A: email="test@bni.com", password="TestPass1", status=ACTIVE, chapter_role=MEMBER
  - Member B: email="admin@bni.com", password="AdminPass1", status=ACTIVE, chapter_role=ADMIN
  - Member C: email="inactive@bni.com", password="Pass1234", status=INACTIVE

AuthService.login tests:
1. Valid credentials → returns accessToken, refreshToken, decrypted member
2. Wrong password → throws INVALID_CREDENTIALS (not a different error — same message)
3. Non-existent email → throws INVALID_CREDENTIALS (same message — no enumeration)
4. Inactive member → throws INVALID_CREDENTIALS
5. Null password_hash → throws PASSWORD_NOT_SET
6. 5 failed attempts → 6th attempt throws ACCOUNT_LOCKED
7. After lockout expires → login succeeds again (mock Date)
8. Successful login resets failed_login_attempts to 0

AuthService.setPassword tests:
9. ADMIN sets password for any member → password_hash updated
10. MEMBER sets own password → succeeds
11. MEMBER tries to set another member's password → throws FORBIDDEN
12. Password under 8 chars → throws WEAK_PASSWORD
13. Password with no number → throws WEAK_PASSWORD
14. After setPassword → login with new password succeeds

AuthService.refreshTokens tests:
15. Valid refresh token → returns new access + refresh tokens
16. Old refresh token invalidated after rotation (second use throws error)
17. Expired refresh token → throws INVALID_REFRESH_TOKEN
18. Revoked refresh token → throws INVALID_REFRESH_TOKEN

JWT utility tests:
19. Access token expires after 15 minutes (mock timers)
20. verifyAccessToken rejects tampered token
21. JWT payload contains memberId, chapterId, and role
22. requireRole allows correct role, throws FORBIDDEN for wrong role

Rate limiting tests (src/__tests__/rateLimit.test.ts):
23. Under limit → returns true (not rate limited)
24. Over limit → returns false (rate limited)
25. After window expires → counter resets

Run: npm test -- --testPathPattern="auth|rateLimit"
Fix all failures.
```

---

### FIX-P02 · Auth Bug Fix

```
Review the complete auth flow end-to-end:

Security checks:
1. Confirm no password value ever appears in any log, audit_log value, or API response body
   Search codebase: grep -r "password" src/ | grep -v "password_hash\|REDACTED\|newPassword\|setPassword"
   Anything suspicious → fix immediately
2. Confirm HttpOnly cookie has Secure=true, SameSite=strict, path=/api/auth/refresh
3. Verify refresh token rotation: after one refresh, the old token is revoked
   Test: call /api/auth/refresh twice with the same cookie → second should return 401
4. Verify JWT payload contains chapterId — check with jwt.decode() in a test
5. Confirm middleware blocks /api/auth/set-password for unauthenticated users (it is NOT in the exempt list)

Rate limiting check:
6. Call POST /api/auth/login 6 times rapidly with wrong password
   The 6th call should return 429 RATE_LIMIT_EXCEEDED
   Wait for window to reset (or mock time) → should succeed again

Account lockout check:
7. Call login 5 times with wrong password for the same account
   6th call → ACCOUNT_LOCKED (not INVALID_CREDENTIALS)
   Verify locked_until is set ~15 minutes in the future in the DB

Token storage check:
8. Open browser DevTools → Application → Local Storage
   Access token must NOT appear there
9. Open Application → Cookies
   refresh_token cookie must be present and HttpOnly (no JS access)
10. Refresh the page — does the app auto-restore session via /api/auth/refresh? (check Network tab)

PWA check:
11. Middleware allows /sw.js and /offline.html — test: curl http://localhost:3000/sw.js (no redirect to login)

TypeScript:
12. Run npx tsc --noEmit — fix all errors

Fix all issues found.
```

---

## PHASE 3 — MOD-01 MEMBER MASTER (BACKEND)

---

### P03-01 · MemberService

```
Create src/services/MemberService.ts with these methods. All methods must use the crypto utilities from src/lib/crypto.ts for PII fields.

Types to create first in src/types/member.ts:
- MemberStatus: 'ACTIVE' | 'INACTIVE' | 'ARCHIVED'
- ChapterRole: 'MEMBER' | 'PRESIDENT' | 'VP' | 'SECRETARY' | 'TREASURER' | 'ADMIN'
- GeocodeStatus: 'PENDING' | 'RESOLVED' | 'FAILED'
- MemberDecrypted: all fields from Prisma member model but with mobile, whatsapp, email as plain strings (not Buffer)
- CreateMemberDto: { full_name, mobile, whatsapp, email, biz_category, one_line_summary, intro_text?, office_address, chapter_role, joining_date }
  Note: email is REQUIRED — it is the login identifier
- UpdateMemberDto: Partial<CreateMemberDto>

Methods:

createMember(chapterId: string, dto: CreateMemberDto, actorId: string): Promise<MemberDecrypted>
  1. Validate required fields — throw 422 if missing. Email must be valid email format.
  2. Normalise mobile and whatsapp (normalisePhone)
  3. Normalise email (normaliseEmail: trim + toLowerCase)
  4. Hash mobile, whatsapp, and email for duplicate checks
  5. Call checkDuplicates — check mobile_hash, whatsapp_hash, AND email_hash
  6. Encrypt mobile, whatsapp, email (all three)
  7. Insert member with generated UUID
     — password_hash: null (Admin must call setPassword separately — member cannot log in yet)
     — failed_login_attempts: 0, locked_until: null
  8. Write audit log: operation=CREATE, entity_type='members'
  9. Trigger geocoding async via setImmediate
  10. Return decrypted member

updateMember(memberId: string, chapterId: string, dto: UpdateMemberDto, actorId: string): Promise<MemberDecrypted>
  1. Load existing member (throw 404 if not found)
  2. If mobile/whatsapp changing: re-hash, re-check duplicate excluding self
  3. Re-encrypt changed PII fields
  4. If office_address changing: reset geocode_status to PENDING, trigger geocoding async
  5. Update member
  6. Write audit log per changed field
  7. Return decrypted member

archiveMember(memberId: string, reason: string, actorId: string, actorRole: string): Promise<void>
  1. Load member
  2. Throw 409 if already ARCHIVED
  3. Set status=ARCHIVED, comm_eligible=false, rec_active=false
  4. Write audit log with reason in new_value

restoreMember(memberId: string, actorId: string, actorRole: string): Promise<void>
  1. Load member
  2. Set status=ACTIVE
  3. Write audit log

getMembersByChapter(chapterId: string, filters: { status?: string; role?: string; search?: string }): Promise<MemberDecrypted[]>
  1. Query with filters
  2. Decrypt all PII fields before returning

getMemberById(memberId: string, chapterId: string): Promise<MemberDecrypted>
  1. Find member
  2. Throw 404 if not found or not in this chapter
  3. Decrypt and return

getEligibleForRecommendation(chapterId: string): Promise<MemberDecrypted[]>
  1. WHERE status=ACTIVE AND comm_eligible=true AND rec_active=true AND geocode_status=RESOLVED
  2. Decrypt and return

checkDuplicates(chapterId: string, hashes: { mobileHash?: string; whatsappHash?: string; emailHash?: string }, excludeMemberId?: string): Promise<void>
  1. Query members by each provided hash (only check hashes that are provided)
  2. If mobile_hash conflict: throw AppError('MEMBER_DUPLICATE_MOBILE', 409)
  3. If whatsapp_hash conflict: throw AppError('MEMBER_DUPLICATE_WHATSAPP', 409)
  4. If email_hash conflict: throw AppError('MEMBER_DUPLICATE_EMAIL', 409)
  5. Always exclude excludeMemberId from the check (for update operations)

private decryptMember(member: members): MemberDecrypted
  — Decrypt mobile_enc, whatsapp_enc, email_enc using crypto.decrypt()
```

---

### P03-02 · AuditService

```
Create src/services/AuditService.ts:

type AuditEntry = {
  entityType: string;
  entityId: string;
  operation: 'CREATE' | 'UPDATE' | 'ARCHIVE' | 'RESTORE' | 'EXCLUDE' | 'COMPLETE';
  fieldName?: string;
  oldValue?: string;
  newValue?: string;
  actorId: string;
  actorRole: string;
  source: 'UI' | 'API' | 'SCHEDULER' | 'WEBHOOK';
}

export class AuditService {
  static async log(entry: AuditEntry): Promise<void>
  — Fire-and-forget pattern: never throw from this method
  — Catch and log to console.error only
  — INSERT into audit_logs
  
  static async getAuditLogs(filters: {
    entityType?: string;
    entityId?: string;
    actorId?: string;
    fromDate?: Date;
    toDate?: Date;
    page?: number;
    pageSize?: number;
  }): Promise<{ logs: audit_logs[]; total: number }>
}
```

---

### P03-03 · Chapter Settings Service

```
Create src/services/ChapterService.ts:

getChapterSettings(chapterId: string): Promise<chapters>
  — Fetch full chapter record

updateChapterSettings(chapterId: string, dto: Partial<chapters>, actorId: string, actorRole: string): Promise<chapters>
  — For each changed field: write audit log entry with old and new values
  — Then update chapter

getShareableFields(chapterId: string): Promise<shareable_fields[]>
  — Return all fields for chapter

updateShareableFields(chapterId: string, updates: { field_name: string; is_shareable: boolean }[], actorId: string): Promise<shareable_fields[]>
  — Upsert each field
  — Write audit log per changed field
  — Return updated list

getShareableFieldMap(chapterId: string): Promise<Record<string, boolean>>
  — Returns { full_name: true, biz_category: true, ... }
  — Used by WhatsApp message builder
```

---

### P03-04 · MOD-01 API Route Handlers

```
Create all MOD-01 API route handlers. Each must use withErrorHandling wrapper and requireAuth + requireRole at the top.

1. src/app/api/chapters/[chapterId]/members/route.ts
   GET  → requireAuth, any role → MemberService.getMembersByChapter
   POST → requireAuth, ADMIN only → validate body with Zod CreateMemberSchema → MemberService.createMember

2. src/app/api/chapters/[chapterId]/members/[memberId]/route.ts
   GET   → requireAuth, any role → MemberService.getMemberById
   PATCH → requireAuth, ADMIN or self (actor.memberId === memberId) → MemberService.updateMember

3. src/app/api/chapters/[chapterId]/members/[memberId]/archive/route.ts
   POST → requireAuth, ADMIN only → body: { reason: string } → MemberService.archiveMember

4. src/app/api/chapters/[chapterId]/members/[memberId]/restore/route.ts
   POST → requireAuth, ADMIN only → MemberService.restoreMember

5. src/app/api/chapters/[chapterId]/settings/route.ts
   GET   → requireAuth, ADMIN or LT → ChapterService.getChapterSettings
   PATCH → requireAuth, ADMIN or PRESIDENT → ChapterService.updateChapterSettings

6. src/app/api/chapters/[chapterId]/shareable-fields/route.ts
   GET   → requireAuth, ADMIN → ChapterService.getShareableFields
   PATCH → requireAuth, ADMIN → body: { updates: [{field_name, is_shareable}] } → ChapterService.updateShareableFields

7. src/app/api/chapters/[chapterId]/audit-logs/route.ts
   GET → requireAuth, ADMIN or LT → AuditService.getAuditLogs with query param filters

Create Zod schemas in src/lib/validation.ts for all request bodies:

CreateMemberSchema:
  full_name: z.string().min(2).max(150)
  mobile: z.string().min(10).max(20)
  whatsapp: z.string().min(10).max(20)
  email: z.string().email()   ← required, must be valid email format
  biz_category: z.string().min(2).max(100)
  one_line_summary: z.string().min(10).max(250)
  intro_text: z.string().max(400).optional()
  office_address: z.string().min(10)
  chapter_role: z.enum(['MEMBER','PRESIDENT','VP','SECRETARY','TREASURER','ADMIN'])
  joining_date: z.string().datetime()

UpdateMemberSchema: All fields from CreateMemberSchema made optional via .partial()

LoginSchema:
  email: z.string().email()
  password: z.string().min(1)

SetPasswordSchema:
  memberId: z.string().uuid()
  newPassword: z.string().min(8)
```

---

### TEST-P03 · MOD-01 Backend Tests

```
Create src/__tests__/memberService.test.ts. Write integration tests that use the real database (use a test chapter seeded in beforeAll):

1. createMember — happy path: creates member, returns decrypted fields
2. createMember — duplicate mobile: throws MEMBER_DUPLICATE_MOBILE
3. createMember — duplicate whatsapp: throws MEMBER_DUPLICATE_WHATSAPP
4. createMember — missing required field: throws validation error
5. updateMember — changes name: audit log written with old and new value
6. updateMember — changes address: geocode_status reset to PENDING
7. archiveMember — sets status=ARCHIVED, comm_eligible=false, rec_active=false
8. archiveMember — already archived member: throws 409
9. getMembersByChapter — filters by status correctly
10. checkDuplicates — allows same phone if it belongs to self (excludeMemberId works)

Create src/__tests__/chapterService.test.ts:
1. updateChapterSettings — writes audit log per changed field
2. updateShareableFields — upserts correctly
3. getShareableFieldMap — returns correct boolean map

Run: npm test -- --testPathPattern="memberService|chapterService"
Fix all failures.
```

---

### FIX-P03 · MOD-01 Backend Bug Fix

```
Review all MOD-01 backend code for:

1. Check that encrypted Bytes fields are never accidentally sent to the client without decryption
2. Verify all Zod schemas match the actual DTO types
3. Check that the audit log is always written even if the main operation succeeds — test by checking DB after each operation
4. Verify that getEligibleForRecommendation correctly filters out members with missing required fields (biz_category, one_line_summary, office_address cannot be empty strings)
5. Check that all API routes return the correct HTTP status codes (201 for POST, 200 for GET, 200 for PATCH)
6. Run: npx tsc --noEmit and fix all TypeScript errors

Fix everything found.
```

---

## PHASE 4 — MOD-01 MEMBER MASTER (FRONTEND)

---

### P04-01 · Navigation + Dashboard Shell

```
Create the main dashboard shell:

1. src/app/(dashboard)/layout.tsx — Dashboard layout with:
   - Top navigation bar: BNI logo/name (navy background), nav links, user menu
   - Mobile: hamburger menu that opens a slide-in drawer
   - Nav links: Members, Matrix, Map, Recommendations, Settings
   - User menu: shows logged-in member name, Logout option
   - PWA offline indicator: small banner at top if navigator.onLine is false (use 'use client' sub-component)

2. src/components/ui/OfflineIndicator.tsx ('use client'):
   - Listens to online/offline browser events
   - Shows a yellow banner: "You are offline — showing cached data" when offline
   - Hides when back online

3. src/components/ui/StatusBadge.tsx:
   - Props: status: 'ACTIVE' | 'INACTIVE' | 'ARCHIVED' | 'QUEUED' | 'SENT' | 'COMPLETED' | 'EXPIRED' | 'EXCLUDED'
   - Renders a colored pill badge for each status
```

---

### P04-02 · Member List Page

```
Create src/app/(dashboard)/chapter/members/page.tsx as a Server Component:

- Fetch members from MemberService directly (server-side, no API call needed)
- Pass chapterId from session (use getServerSession)
- Accept searchParams for: status (default 'ACTIVE'), role, search
- Render a table of members with columns: Name, Category, Role, Status, Joining Date, Actions
- Actions: View, Edit (ADMIN only), Archive (ADMIN only)
- Include a filter bar (create as a Client Component: MemberFilters.tsx) with:
  * Status dropdown (All, Active, Inactive, Archived)
  * Category text filter
  * Search input
  * Filters update URL searchParams (no page reload — use Next.js router.push)
- "Add Member" button (ADMIN only) that links to /chapter/members/new
- Show member count
- Table is responsive: on mobile, show name + status only, with expand on tap

Create src/components/members/MemberTable.tsx as a Client Component (needs sorting state).
```

---

### P04-03 · Create/Edit Member Form

```
Create src/app/(dashboard)/chapter/members/new/page.tsx as a Client Component.

This is the most important form in MOD-01. It must:

1. Have these fields with proper labels and validation:
   - Full Name (required, text)
   - Mobile Number (required, with country code selector defaulting to +91)
   - WhatsApp Number (required, checkbox: "Same as mobile" auto-fills)
   - Email (required — this is the member's login identifier. Show hint: "Used for login access to BNI Connect")
   - Business Category (required, text with autocomplete from existing categories in chapter)
   - One-Line Business Summary (required, max 250 chars, char counter)
   - Introduction Text (optional, max 400 chars, char counter, hint: "Override for WhatsApp messages")
   - Office Address (required — Google Places Autocomplete input)
   - Chapter Role (required, dropdown: Member/President/VP/Secretary/Treasurer/Admin)
   - Joining Date (required, date picker)
   - Communication Eligible (toggle, default on)
   - Recommendation Active (toggle, default on)

2. Google Places Autocomplete on the Office Address field:
   - Use google.maps.places.Autocomplete
   - On place_changed: populate the address field with formatted_address
   - Show a small map preview pin after address is selected (use a static Maps image URL)

3. Form submission:
   - POST to /api/chapters/[chapterId]/members
   - Show field-level errors from API response
   - Show success toast and redirect to member profile on success
   - Loading state on submit button

4. Create src/app/(dashboard)/chapter/members/[memberId]/page.tsx (Server Component):
   - Load member by ID
   - Show full profile card with all fields
   - Show "Edit" button that opens an Edit drawer (Client Component) using the same form fields
   - Show interaction history (last 5 completed 1-2-1s)

Create src/hooks/usePlacesAutocomplete.ts — a custom hook that initialises Google Places on a ref input.
```

---

### P04-04 · Chapter Settings Page

```
Create src/app/(dashboard)/chapter/settings/page.tsx as a Client Component:

Tab 1 — Meeting & Communication Settings:
- Meeting Day (dropdown: Sunday-Saturday)
- Meeting Start Time (time picker)
- Meeting Duration (number input, minutes)
- RSVP Reminder Schedule (editable list: offset_day + time pairs, add/remove)
- Quiet Hours Start/End (time pickers)

Tab 2 — 1-2-1 Engine Settings:
- Lookback Window (slider: 30-365 days, show value)
- Recommendation Cooldown (slider: 14-90 days)
- Max Recommendations per Member per Cycle (number: 1-5)
- Post-Meeting Trigger Delay (number input, minutes)
- Recommendation Expiry (number input, days)

Tab 3 — Shareable Fields:
- List all 6 fields with toggle switches
- Warning callout: "These fields will be included in WhatsApp introduction messages sent to members"
- Show a live preview of what the WhatsApp message would look like based on current toggles

Save button per tab. Show success/error toast. ADMIN and PRESIDENT roles only.
```

---

### P04-05 · Audit Log Page

```
Create src/app/(dashboard)/chapter/audit/page.tsx as a Server Component:

- Paginated table (20 per page) with columns: Date/Time, Entity, Operation, Field, Old Value, New Value, Actor, Source
- Filters (passed as searchParams): entity_type, date from/to
- Date/Time formatted in chapter timezone
- Values truncated to 50 chars with tooltip for full value
- Export button: downloads audit log as CSV for current filters (create GET API route that returns CSV)
- Mobile: scrollable horizontal table
```

---

### TEST-P04 · MOD-01 Frontend Tests

```
Install Playwright for end-to-end tests:
  npm install -D @playwright/test
  npx playwright install chromium

Create playwright.config.ts targeting localhost:3000.

Create tests/e2e/members.spec.ts:

1. Test: Login page renders correctly with email + password fields
2b. Test: Enter wrong password → "Invalid email or password" error shown
2c. Test: Enter non-existent email → same "Invalid email or password" error (no enumeration)
2. Test: Member list page loads and shows members from seed data
3. Test: Status filter changes the member list displayed
4. Test: Create member form validates required fields before submit
5. Test: Create member form shows error message for duplicate mobile
6. Test: Member profile page shows correct member details
7. Test: Settings page tabs switch correctly
8. Test: Shareable fields toggles save correctly

Run: npx playwright test tests/e2e/members.spec.ts
Fix any failures.
```

---

### FIX-P04 · MOD-01 Frontend Bug Fix

```
Test the complete MOD-01 UI in the browser. Check:
1. Open the member list page — are all columns displaying correctly on both desktop and mobile?
2. Does the Google Places autocomplete work on the Create Member form? (requires NEXT_PUBLIC_GOOGLE_MAPS_KEY to be set)
3. Does the "Same as mobile" WhatsApp checkbox work correctly?
4. Does the Chapter Settings page correctly load existing values from the database?
5. Does the audit log page paginate correctly?
6. Check browser console for any React errors or warnings — fix all
7. Check mobile view (use browser DevTools device mode) — is the navigation drawer working?
8. Test the offline indicator: use DevTools Network → Offline mode, verify the offline banner appears

Fix all issues found. Run npx tsc --noEmit.
```

---

## PHASE 5 — MOD-04 PAIRING ENGINE (BACKEND)

---

### P05-01 · PairingEngine Service

```
Create src/services/PairingEngine.ts:

Types (add to src/types/recommendation.ts):
- PairCandidate: { member_a: MemberDecrypted; member_b: MemberDecrypted; lastInteractionDate: Date | null }
- RecommendationStatus: 'QUEUED' | 'SENT' | 'COMPLETED' | 'EXPIRED' | 'EXCLUDED'

class PairingEngine:

async computeEligiblePairs(chapterId: string, chapter: chapters): Promise<PairCandidate[]>

Implementation:
1. Get eligible members via MemberService.getEligibleForRecommendation(chapterId)
2. If < 2 members: return []
3. Generate all unique pairs — always store with member_a_id < member_b_id (string sort)
4. Load 4 lookup sets in parallel using Promise.all:
   a) recentMet: Set of pair keys from member_interactions where interaction_date >= now - lookback_days
   b) openRecs: Set of pair keys from recommendations where status IN ('QUEUED','SENT')
   c) cooldownSet: Set of pair keys from recommendations where updated_at >= now - cooldown_days
   d) excludedSet: Set of pair keys from recommendations where status = 'EXCLUDED'
5. Also load lastMetMap: Map<pairKey, Date> of most recent interaction_date per pair
6. Filter candidates — keep only pairs where: not in recentMet AND not in openRecs AND not in cooldownSet AND not in excludedSet
7. Map filtered pairs to PairCandidate with lastInteractionDate from lastMetMap

rankAndCap(pairs: PairCandidate[], maxPerMember: number): PairCandidate[]
1. Sort: null lastInteractionDate first (never met = highest priority), then ascending by date (oldest first)
2. Walk the sorted list, track per-member count
3. Skip pair if either member already has maxPerMember recommendations in this batch
4. Return filtered list

Helper: pairKey(a: string, b: string): string
— Returns `${min}|${max}` always (consistent ordering)
```

---

### P05-02 · RecommendationService

```
Create src/services/RecommendationService.ts:

async runRecommendationCycle(chapterId: string, triggerType: 'POST_MEETING' | 'SCHEDULED' | 'MANUAL', meetingId?: string): Promise<recommendation_runs>

Steps:
1. Create recommendation_runs record with status=RUNNING
2. Load chapter settings
3. Call PairingEngine.computeEligiblePairs
4. Call PairingEngine.rankAndCap with chapter.max_recs_per_cycle
5. For each pair: call createAndDispatch(pair, run.run_id, chapter)
6. Update run record: status=COMPLETED, pairs_evaluated, pairs_sent, pairs_skipped, completed_at
7. On any thrown error: update run status=FAILED, error_detail, re-throw

async createAndDispatch(pair: PairCandidate, runId: string, chapter: chapters): Promise<void>
1. Use Prisma transaction with SELECT FOR UPDATE pattern to prevent duplicate active recs:
   - Query: SELECT rec_id FROM recommendations WHERE member_a_id=? AND member_b_id=? AND status IN ('QUEUED','SENT') FOR UPDATE
   - If found: increment pairs_skipped, return (don't throw)
2. INSERT recommendation with status=QUEUED
3. Call WhatsAppService.sendIntroduction(rec, memberA, memberB, chapter) — stub for now
4. On success: UPDATE status=SENT, wa_msg_id_a, wa_msg_id_b, sent_at
5. On failure: increment send_attempts. If attempts >= 2: leave QUEUED, log admin alert

async completeRecommendation(recId: string, confirmedByMemberId: string, interactionDate: Date, notes: string | undefined, source: string, actorId: string, actorRole: string): Promise<void>
1. Load rec — throw 404 if not found
2. Throw 409 if status already COMPLETED
3. In a transaction:
   a) Ensure member_a_id < member_b_id (for interaction table constraint)
   b) INSERT member_interactions (interaction_date, source, confirmed_by, rec_id, notes)
   c) UPDATE recommendation: status=COMPLETED, completed_at
4. Write audit log: operation=COMPLETE

async excludePair(recId: string, reason: string, actorId: string, actorRole: string): Promise<void>
1. Load rec
2. UPDATE status=EXCLUDED, excluded_at, excluded_by, excluded_reason
3. Write audit log

async reinstateRecommendation(recId: string, actorId: string, actorRole: string): Promise<void>
1. Load rec — must be EXCLUDED
2. UPDATE status=QUEUED (will be dispatched on next run)
3. Write audit log

async createManualPairing(chapterId: string, memberAId: string, memberBId: string, actorId: string, actorRole: string): Promise<recommendations>
1. Apply eligibility rules (all except cooldown)
2. Create and dispatch

async expireStaleRecommendations(chapterId: string): Promise<number>
1. UPDATE recommendations SET status=EXPIRED, expired_at=NOW()
   WHERE chapter_id=? AND status='SENT'
   AND sent_at < DATE_SUB(NOW(), INTERVAL rec_expiry_days DAY)
2. Return count of expired

async handleWebhookReply(waMessageId: string, senderWhatsapp: string, replyText: string): Promise<void>
1. Normalise and hash senderWhatsapp
2. Find member by whatsapp_hash
3. If not found: log to console.warn (admin exception) and return
4. Normalise replyText to UPPERCASE, trim
5. Map: ['DONE','COMPLETED','MET','✅'] → complete the recommendation
6. Map: ['STOP'] → set member.rec_active=false, write audit log
7. Else: log to console.warn with raw reply (admin exception list — MVP)
8. Find the SENT rec for this member (most recent SENT involving this member)
```

---

### P05-03 · Recommendation API Routes

```
Create all MOD-04 recommendation API route handlers:

1. GET /api/chapters/[chapterId]/recommendations
   — requireAuth, ADMIN or LT
   — Query params: status, member_id, page, pageSize
   — Return paginated recommendations list

2. POST /api/chapters/[chapterId]/recommendations/run
   — requireAuth, ADMIN or LT
   — Call RecommendationService.runRecommendationCycle with trigger_type=MANUAL
   — Return run record (the cycle runs synchronously for manual triggers; for scheduled it runs in background)

3. GET /api/chapters/[chapterId]/recommendations/runs/[runId]
   — requireAuth, ADMIN or LT
   — Return run record with stats

4. POST /api/chapters/[chapterId]/recommendations/manual
   — requireAuth, ADMIN or LT
   — Body: { member_a_id, member_b_id }
   — Call RecommendationService.createManualPairing

5. POST /api/chapters/[chapterId]/recommendations/[recId]/complete
   — requireAuth, ADMIN or LT or (MEMBER if they are member_a or member_b)
   — Body: { interaction_date: string (ISO date), notes?: string }
   — Call RecommendationService.completeRecommendation

6. POST /api/chapters/[chapterId]/recommendations/[recId]/exclude
   — requireAuth, ADMIN or LT
   — Body: { reason: string }
   — Call RecommendationService.excludePair

7. POST /api/chapters/[chapterId]/recommendations/[recId]/reinstate
   — requireAuth, ADMIN or LT
   — Call RecommendationService.reinstateRecommendation
```

---

### TEST-P05 · Pairing Engine Tests

```
Create src/__tests__/pairingEngine.test.ts:

Setup: Create a test chapter with 5 test members (all ACTIVE, comm_eligible, rec_active, geocode_status=RESOLVED).

Tests:
1. computeEligiblePairs returns all unique pairs (10 pairs for 5 members) when no history
2. computeEligiblePairs excludes pairs that met within lookback window
3. computeEligiblePairs excludes pairs with open recommendations
4. computeEligiblePairs excludes pairs in cooldown period
5. computeEligiblePairs excludes EXCLUDED pairs
6. rankAndCap sorts: null lastInteractionDate first (never-met pairs first)
7. rankAndCap enforces per-member cap correctly
8. rankAndCap returns fewer pairs than cap when members are exhausted

Create src/__tests__/recommendationService.test.ts:
1. runRecommendationCycle creates run record and recommendation records
2. runRecommendationCycle handles 0 eligible pairs gracefully (run completes with 0 sent)
3. createAndDispatch prevents duplicate QUEUED/SENT rec for same pair (transaction test)
4. completeRecommendation creates member_interaction and updates rec status
5. completeRecommendation throws 409 if already COMPLETED
6. expireStaleRecommendations expires correct records
7. handleWebhookReply DONE: marks rec as COMPLETED
8. handleWebhookReply STOP: sets member rec_active=false
9. handleWebhookReply unknown text: does not throw (graceful)

Mock WhatsApp API calls in all tests.
Run: npm test -- --testPathPattern="pairingEngine|recommendationService"
Fix all failures.
```

---

### FIX-P05 · Pairing Engine Bug Fix

```
Review PairingEngine and RecommendationService for:

1. The pairKey function — verify it always produces the same key regardless of which member is passed first (A,B and B,A should return identical key)
2. The SELECT FOR UPDATE transaction — test it actually prevents duplicate recommendations by simulating concurrent requests
3. Check that expireStaleRecommendations uses the chapter's rec_expiry_days setting, not a hardcoded value
4. Verify that handleWebhookReply finds the correct SENT recommendation when a member has multiple SENT recs — it should find the most recently sent one
5. Check that the audit log for COMPLETE includes the interaction_date in new_value
6. Run npx tsc --noEmit on all new files

Fix all issues.
```

---

## PHASE 6 — WHATSAPP INTEGRATION (META CLOUD API)

> **Stack decision:** Meta WhatsApp Cloud API — direct, no middleware.
> Base URL: `https://graph.facebook.com/v19.0`
> Free tier: 1,000 conversations/month. One chapter = effectively free.

---

### P06-01 · Meta Cloud API Adapter

```
Create src/adapters/WhatsAppAdapter.ts:

Define the interface (kept identical to original — adapter pattern means nothing
else in the codebase changes when the provider changes):

interface WhatsAppAdapter {
  sendTemplate(params: {
    to: string;
    templateName: string;
    language: string;
    components: Array<{ type: string; parameters: Array<{ type: string; text: string }> }>;
  }): Promise<{ messageId: string }>;

  verifyWebhookSignature(payload: Buffer, signature: string): boolean;

  parseInboundMessage(body: unknown): { from: string; messageId: string; text: string } | null;
}

Implement MetaCloudApiAdapter:

Constants from env:
  PHONE_NUMBER_ID = process.env.WHATSAPP_PHONE_NUMBER_ID
  API_TOKEN       = process.env.WHATSAPP_API_TOKEN
  BASE_URL        = `https://graph.facebook.com/v19.0/${PHONE_NUMBER_ID}`

sendTemplate(params):
  POST ${BASE_URL}/messages
  Headers:
    Authorization: Bearer ${API_TOKEN}
    Content-Type: application/json
  Body:
  {
    "messaging_product": "whatsapp",
    "to": params.to,          // E.164 WITHOUT the + sign: "919876543210"
    "type": "template",
    "template": {
      "name": params.templateName,
      "language": { "code": params.language },
      "components": params.components
    }
  }
  Parse response:
    On HTTP 200: return { messageId: data.messages[0].id }
    On HTTP 4xx/5xx: throw new AppError with Meta error_data.details from response body

verifyWebhookSignature(payload, signature):
  Meta sends header: x-hub-signature-256: sha256=<hmac>
  Compute: crypto.createHmac('sha256', process.env.WHATSAPP_API_TOKEN!)
                 .update(payload).digest('hex')
  Compare: 'sha256=' + computed === signature  (use timingSafeEqual to prevent timing attacks)
  Return boolean

parseInboundMessage(body):
  Meta webhook payload shape:
    body.object === 'whatsapp_business_account'
    body.entry[0].changes[0].value.messages[0]   ← the actual message
    body.entry[0].changes[0].value.statuses[0]   ← delivery/read receipts (ignore these)

  Steps:
  1. Check body.object === 'whatsapp_business_account' — return null if not
  2. Safely navigate to messages array — return null if not present (it is a status update)
  3. Extract first message:
       const msg = body.entry?.[0]?.changes?.[0]?.value?.messages?.[0]
  4. If msg.type !== 'text': return null (ignore image, audio, etc.)
  5. Return:
       { from: msg.from,        // e.g. "919876543210" — no + prefix
         messageId: msg.id,
         text: msg.text.body }

Implement StubWhatsAppAdapter (unchanged from original design):
  sendTemplate: logs [WHATSAPP-STUB] + template name + recipient, returns { messageId: 'stub-' + Date.now() }
  verifyWebhookSignature: always returns true
  parseInboundMessage: returns null

Create src/adapters/index.ts:
  export function getWhatsAppAdapter(): WhatsAppAdapter
  — If WHATSAPP_PROVIDER === 'stub' OR NODE_ENV === 'test': return new StubWhatsAppAdapter()
  — Else: return new MetaCloudApiAdapter()
  — Export as singleton (instantiate once, reuse across requests)

Add to src/lib/env.ts validation:
  WHATSAPP_PHONE_NUMBER_ID: z.string().min(10)
  WHATSAPP_BUSINESS_ACCOUNT_ID: z.string().min(10)
  WHATSAPP_API_TOKEN: z.string().min(20)
  WHATSAPP_VERIFY_TOKEN: z.string().min(8)
  WHATSAPP_TEMPLATE_NAME: z.string().default('bni_121_introduction')
  // WHATSAPP_OTP_TEMPLATE_NAME: REMOVED — auth uses email+password
```

---

### P06-02 · WhatsAppService

```
Create src/services/WhatsAppService.ts:

// sendOtp: REMOVED. Auth uses email+password — WhatsApp not involved in auth.

async sendIntroduction(
  rec: recommendations,
  memberA: MemberDecrypted,
  memberB: MemberDecrypted,
  chapter: chapters
): Promise<{ msgIdA: string; msgIdB: string }>

  1. Load shareable fields map: await ChapterService.getShareableFieldMap(chapter.chapter_id)
  2. Build 8-variable components array for A (about B):
       [
         { type:'text', text: memberA.full_name },                          // {{1}} recipient name
         { type:'text', text: String(chapter.lookback_days) },              // {{2}} lookback days
         { type:'text', text: memberB.full_name },                          // {{3}} contact name
         { type:'text', text: sf.biz_category ? memberB.biz_category : '—' },   // {{4}}
         { type:'text', text: sf.one_line_summary ? (memberB.intro_text ?? memberB.one_line_summary) : '—' }, // {{5}}
         { type:'text', text: sf.whatsapp ? memberB.whatsapp : '—' },      // {{6}}
         { type:'text', text: sf.office_address ? formatLocation(memberB, chapter) : '—' }, // {{7}}
         { type:'text', text: buildMapsLink(memberB) },                     // {{8}} always included
       ]
  3. Build reverse components array for B (about A)
  4. Send both via Promise.allSettled:
       const [resultA, resultB] = await Promise.allSettled([
         adapter.sendTemplate({ to: normaliseToMetaFormat(memberA.whatsapp), templateName: ..., language: 'en', components: componentsA }),
         adapter.sendTemplate({ to: normaliseToMetaFormat(memberB.whatsapp), templateName: ..., language: 'en', components: componentsB }),
       ])
  5. If either rejected: throw WhatsAppSendError({ memberA: resultA.status, memberB: resultB.status })
  6. Return { msgIdA: resultA.value.messageId, msgIdB: resultB.value.messageId }

async sendAcknowledgement(whatsappNumber: string, contactName: string): Promise<void>
  Call adapter.sendTemplate({
    to: normaliseToMetaFormat(whatsappNumber),
    templateName: 'bni_121_complete',          // simple 1-variable template
    language: 'en',
    components: [{ type:'body', parameters:[{ type:'text', text: contactName }] }]
  })
  — Template body: "Great! Your 1-2-1 with {{1}} has been recorded. Well done! 🎉"

private normaliseToMetaFormat(phone: string): string
  — Remove all non-digits: phone.replace(/\D/g, '')
  — Meta requires E.164 WITHOUT the + prefix: "919876543210" not "+919876543210"
  — Return the cleaned string

private buildMapsLink(member: MemberDecrypted): string
  — If geocode_status=RESOLVED: `https://www.google.com/maps?q=${member.latitude},${member.longitude}`
  — Else: `https://www.google.com/maps?q=${encodeURIComponent(member.office_address)}`

private formatLocation(member: MemberDecrypted, chapter: chapters): string
  — If chapter.location_display_mode === 'AREA_ONLY': extractArea(member.office_address)
  — Else: member.office_address

private extractArea(fullAddress: string): string
  — Split by comma, take last 2 parts, trim, rejoin
  — e.g. "123 SG Highway, Prahlad Nagar, Ahmedabad, Gujarat 380015"
      → "Ahmedabad, Gujarat 380015"
```

---

### P06-03 · WhatsApp Webhook Handler (Meta format)

```
Create src/app/api/webhooks/whatsapp/route.ts:

IMPORTANT: Meta requires TWO handlers on this route — GET for initial verification
and POST for incoming messages.

─── GET handler (Meta webhook verification — one-time setup) ───

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const mode      = searchParams.get('hub.mode');
  const token     = searchParams.get('hub.verify_token');
  const challenge = searchParams.get('hub.challenge');

  if (mode === 'subscribe' && token === process.env.WHATSAPP_VERIFY_TOKEN) {
    // Return challenge as plain text — Meta requires this exact format
    return new Response(challenge, {
      status: 200,
      headers: { 'Content-Type': 'text/plain' }
    });
  }
  return new Response('Forbidden', { status: 403 });
}

─── POST handler (incoming messages from Meta) ───

export async function POST(req: Request) {
  // 1. Read raw body as Buffer — MUST do this before any JSON parsing
  //    because HMAC verification needs the exact bytes Meta sent
  const rawBody = Buffer.from(await req.arrayBuffer());

  // 2. Verify Meta's HMAC-SHA256 signature
  //    Meta sends header: x-hub-signature-256: sha256=<hmac>
  const signature = req.headers.get('x-hub-signature-256') ?? '';
  const adapter   = getWhatsAppAdapter();

  if (!adapter.verifyWebhookSignature(rawBody, signature)) {
    return NextResponse.json({ error: 'Invalid signature' }, { status: 401 });
  }

  // 3. Acknowledge IMMEDIATELY — Meta retries if no 200 within 5 seconds
  //    All processing happens after we return
  const responsePromise = NextResponse.json({ status: 'ok' }, { status: 200 });

  // 4. Parse the payload
  const body = JSON.parse(rawBody.toString('utf8'));
  const message = adapter.parseInboundMessage(body);

  // 5. Process async — do NOT await before returning
  if (message) {
    setImmediate(() => {
      RecommendationService
        .handleWebhookReply(message.messageId, message.from, message.text)
        .catch(err => console.error('[Webhook] handleWebhookReply error:', err));
    });
  }
  // Status updates (delivery receipts, read receipts) are silently ignored
  // because parseInboundMessage returns null for them

  return responsePromise;
}

─── Note on Meta webhook setup ───
When you configure the webhook in Meta Developer dashboard:
  Callback URL: https://your-domain.com/api/webhooks/whatsapp
  Verify Token: (the value of your WHATSAPP_VERIFY_TOKEN env var)
  Webhook fields to subscribe: messages ✓

Meta will call the GET endpoint once to verify. After that, all messages
come as POST requests.
```

---

### TEST-P06 · WhatsApp Integration Tests

```
Create src/__tests__/whatsappService.test.ts:

Use StubWhatsAppAdapter for all tests. Set WHATSAPP_PROVIDER=stub in
jest.config.ts testEnvironment setup (or in jest.setup.ts).

Tests for MetaCloudApiAdapter (unit test the adapter itself, mock fetch):
1. sendTemplate — valid call: verify correct URL, headers, body shape
2. sendTemplate — Meta returns error JSON: throws AppError with Meta error details
3. verifyWebhookSignature — correct HMAC: returns true
4. verifyWebhookSignature — wrong HMAC: returns false
5. parseInboundMessage — valid text message: returns { from, messageId, text }
6. parseInboundMessage — delivery receipt (no messages array): returns null
7. parseInboundMessage — image message (type !== 'text'): returns null
8. parseInboundMessage — malformed payload (missing entry): returns null

Tests for WhatsAppService (use StubAdapter):
9. sendIntroduction — all fields shareable: all 8 template variables populated
10. sendIntroduction — whatsapp not shareable: variable {{6}} is '—'
11. sendIntroduction — AREA_ONLY mode: office variable shows area not full address
12. sendIntroduction — no coordinates: maps link uses URL-encoded address
13. sendIntroduction — one send fails: throws WhatsAppSendError
14. normaliseToMetaFormat — '+91 98765 43210' → '919876543210'
15. normaliseToMetaFormat — '91-98765-43210' → '919876543210'

Tests for webhook route:
16. GET with correct verify_token and hub.mode=subscribe: returns challenge string
17. GET with wrong token: returns 403
18. POST with invalid signature: returns 401
19. POST with valid signature + DONE message: triggers handleWebhookReply
20. POST with valid signature + status update: returns 200, no processing

Run: npm test -- --testPathPattern=whatsapp
Fix all failures.
```

---

### FIX-P06 · WhatsApp Bug Fix

```
Review the Meta Cloud API integration:

1. Phone number format — the most common bug:
   Meta requires the number WITHOUT the + prefix.
   Test normaliseToMetaFormat with these inputs and verify output:
     '+91 98765 43210' → '919876543210'  ✓
     '098765 43210'    → '09876543210'   (Indian local format — WRONG, must have country code)
   Fix: normaliseToMetaFormat should validate the result starts with a country code (minimum 10 digits)

2. Signature verification — timing attack safe:
   Make sure you use crypto.timingSafeEqual() not === for the final comparison.
   If using ===, replace it now.

3. GET vs POST on webhook route:
   curl https://your-domain.com/api/webhooks/whatsapp (GET with no params) → should return 403
   This is safe — only Meta's verification call with the correct token should get 200

4. Template component count:
   The Meta API rejects sendTemplate if the number of parameters in components
   does not exactly match the number of {{n}} variables in the approved template.
   Verify buildTemplateComponents always returns exactly 8 parameters for the intro template.

5. Null-safe parseInboundMessage:
   Production Meta webhooks contain many different event types (status updates,
   read receipts, reaction events). Test parseInboundMessage with 5 different
   real Meta webhook payload shapes (find examples in Meta docs) and verify it
   returns null for all non-text-message events without throwing.

6. Token in env.ts:
   Verify WHATSAPP_VERIFY_TOKEN is in the Zod validation schema.
   If missing, the GET webhook verification will return 403 silently and
   Meta will refuse to save your webhook configuration.

Run npx tsc --noEmit. Fix all TypeScript errors.
```

---

## PHASE 7 — GOOGLE MAPS & GEOCODING

---

### P07-01 · Google Maps Adapter + Geocoding Service

```
Create src/adapters/GoogleMapsAdapter.ts:

interface GoogleMapsAdapter {
  geocode(address: string): Promise<{ lat: number; lng: number } | null>;
}

Implement GoogleMapsAdapterImpl:
- GET https://maps.googleapis.com/maps/api/geocode/json?address={encoded}&key={GOOGLE_MAPS_SERVER_KEY}
- Parse response: if status==='OK', return first result's geometry.location
- If status==='ZERO_RESULTS': return null
- If API error: throw with message
- Never expose GOOGLE_MAPS_SERVER_KEY to any response

Also create StubGoogleMapsAdapter:
- geocode(): always returns { lat: 23.0225, lng: 72.5714 } (Ahmedabad coords for testing)

Create src/adapters/index.ts (add to existing):
- getGoogleMapsAdapter(): GoogleMapsAdapter
  - If NODE_ENV==='test': return StubGoogleMapsAdapter
  - Else: return GoogleMapsAdapterImpl

Create src/services/GeocodingService.ts:

async geocodeMember(memberId: string): Promise<void>
1. Load member from DB
2. Call GoogleMapsAdapter.geocode(member.office_address)
3. If result: UPDATE member latitude, longitude, geocode_status='RESOLVED'
4. If null result: UPDATE geocode_status='FAILED'
5. Write audit log (operation=UPDATE, field_name='geocode_status')
6. Catch and log errors — never throw (geocoding must not break member save)

async retryPending(): Promise<{ retried: number; resolved: number; failed: number }>
1. Find all members WHERE geocode_status IN ('PENDING','FAILED') AND status='ACTIVE'
2. Limit to 50 per run (prevent runaway)
3. For each: call geocodeMember with 100ms delay between calls (rate limit)
4. Return stats
```

---

### P07-02 · Map API Routes

```
Create the map API routes:

1. GET /api/chapters/[chapterId]/map/members
   — requireAuth, any role
   — Query members WHERE status=ACTIVE
   — Return ONLY these fields (do NOT return encrypted PII):
     member_id, full_name, biz_category, latitude, longitude, geocode_status
   — Only include members where geocode_status=RESOLVED as 'pin-ready'
   — Include members with PENDING/FAILED as 'list-only' (no lat/lng)
   — Response shape: { pins: Member[], listOnly: Member[] }

2. GET /api/chapters/[chapterId]/map/member/[memberId]
   — requireAuth, any role
   — Load member + chapter shareable_fields
   — Return info card data — ONLY shareable fields:
     member_id, full_name (always), biz_category (if shareable), 
     one_line_summary or intro_text (if shareable), 
     whatsapp as plain string (if shareable and viewer is not same member), 
     office display (respects location_display_mode), 
     maps_link (always — generated server-side)
   — For LT/ADMIN: always return full address regardless of shareable setting
```

---

### P07-03 · usePlacesAutocomplete Hook (complete implementation)

```
Complete the implementation of src/hooks/usePlacesAutocomplete.ts:

export function usePlacesAutocomplete(inputRef: React.RefObject<HTMLInputElement>) {
  — Initialise google.maps.places.Autocomplete on the input ref
  — Options: types: ['establishment', 'geocode'], componentRestrictions: { country: 'in' }  (India — change to 'in' for BNI India chapters; make this configurable via env)
  — On place_changed: extract formatted_address, lat, lng from the place
  — Return: { selectedAddress: string | null, selectedLat: number | null, selectedLng: number | null }
  — Handle the case where the Google Maps script hasn't loaded yet (window.google might be undefined on first render)
  — Clean up the listener on unmount

Also update the MemberForm to use this hook:
- After address is selected via autocomplete: show a small static map image preview
  URL format: https://maps.googleapis.com/maps/api/staticmap?center={lat},{lng}&zoom=15&size=400x150&markers={lat},{lng}&key={NEXT_PUBLIC_GOOGLE_MAPS_KEY}
- Do NOT pass lat/lng to the API — only pass office_address as text. The server geocodes it.
```

---

### TEST-P07 · Google Maps Tests

```
Create src/__tests__/geocodingService.test.ts:

Use StubGoogleMapsAdapter (returned automatically when NODE_ENV=test).

1. geocodeMember — PENDING member: updates to RESOLVED with coordinates
2. geocodeMember — address with no result (mock adapter to return null): sets status=FAILED
3. geocodeMember — adapter throws error: status remains PENDING (error is caught gracefully)
4. retryPending — processes up to 50 members
5. retryPending — respects rate limiting (add a timer check — 50 members should take at least 4.9 seconds at 100ms delay — or mock the delay for test speed)

Create src/__tests__/mapApi.test.ts:
1. GET map/members — returns only ACTIVE members
2. GET map/members — members with PENDING geocode_status appear in listOnly, not pins
3. GET map/member/[id] — respects shareable_fields (whatsapp not returned if not shareable)
4. GET map/member/[id] — location_display_mode=AREA_ONLY returns only area, not full address

Run: npm test -- --testPathPattern="geocoding|mapApi"
Fix all failures.
```

---

### FIX-P07 · Maps Bug Fix

```
Check the Google Maps integration:
1. Test that GOOGLE_MAPS_SERVER_KEY never appears in any HTTP response or client-side code
2. Verify NEXT_PUBLIC_GOOGLE_MAPS_KEY is correctly restricted — it should ONLY work from your domain, not from curl or other domains
3. Check that the static map preview in MemberForm works (needs NEXT_PUBLIC_GOOGLE_MAPS_KEY)
4. Test the map API with a member who has special characters in their address — verify encoding is correct
5. Verify GeocodingService.retryPending doesn't geocode ARCHIVED members

Fix all issues.
```

---

## PHASE 8 — CROSS ENGAGEMENT MATRIX

---

### P08-01 · MatrixService

```
Create src/services/MatrixService.ts:

Types (add to src/types/matrix.ts):
- CellState: 'SELF' | 'GREEN' | 'AMBER' | 'GAP' | 'EXCLUDED'
- MatrixCell: { state: CellState; lastInteractionDate?: Date; recId?: string; recSentAt?: Date }
- MatrixData: { members: MemberDecrypted[]; cells: MatrixCell[][] }
- MemberCoverage: { totalMembers: number; membersMet: number; notCovered: number; coveragePct: number; lastInteractionDate: Date | null; pendingRecs: number }

async getMatrix(chapterId: string, windowDays: number): Promise<MatrixData>

Implementation:
1. Load all ACTIVE members for chapter (decrypt name, category only — no need for PII)
2. Sort members alphabetically by full_name
3. Load interactions in window: WHERE chapter_id=? AND interaction_date >= cutoff — load member_a_id, member_b_id, interaction_date
4. Load SENT recommendations: WHERE chapter_id=? AND status='SENT' — load member_a_id, member_b_id, rec_id, sent_at
5. Load EXCLUDED recommendations: WHERE chapter_id=? AND status='EXCLUDED'
6. Build N×N matrix:
   - For each [i][j] pair:
     - If i===j: state=SELF
     - Else if pairKey in interactions: state=GREEN, include lastInteractionDate
     - Else if pairKey in sentRecs: state=AMBER, include recId, recSentAt
     - Else if pairKey in excludedRecs: state=EXCLUDED
     - Else: state=GAP
   - Matrix is symmetric: cells[i][j] === cells[j][i]
7. Return { members: sortedMembers, cells: N×N matrix }

async getMemberCoverage(memberId: string, chapterId: string, windowDays: number): Promise<MemberCoverage>
1. Load all ACTIVE members count for chapter (excluding self)
2. Count interactions in window where member_a_id=memberId OR member_b_id=memberId
3. Get last interaction date
4. Count SENT recs involving this member
5. Compute coveragePct = (membersMet / totalMembers) * 100
6. Return MemberCoverage
```

---

### P08-02 · Matrix API Route

```
Create matrix API routes:

1. GET /api/chapters/[chapterId]/matrix
   — requireAuth, ADMIN or LT
   — Query param: windowDays (default 180, allowed: 30, 60, 90, 180, 365)
   — Call MatrixService.getMatrix
   — Response: { members: [...], cells: [[...], [...]], windowDays }

2. GET /api/chapters/[chapterId]/matrix/member/[memberId]
   — requireAuth, ADMIN or LT or self
   — Query param: windowDays (default 180)
   — Call MatrixService.getMemberCoverage
   — Response: MemberCoverage object

3. GET /api/chapters/[chapterId]/recommendations/export
   — requireAuth, ADMIN or LT
   — Returns current matrix and pipeline stats as Excel file
   — Use exceljs to build an XLSX with:
     Sheet 1 "Matrix": the N×N grid with green/amber/white cell background colors
     Sheet 2 "Pipeline": recommendations table with status, members, dates
   — Response: Content-Type application/vnd.openxmlformats-officedocument.spreadsheetml.sheet
```

---

### TEST-P08 · Matrix Tests

```
Create src/__tests__/matrixService.test.ts:

Setup: Create test chapter with 4 members (A, B, C, D). Seed some interactions:
- A and B met 30 days ago
- A and C have a SENT recommendation

Tests:
1. getMatrix — 4 members produces 4×4 matrix
2. getMatrix — A vs B cell is GREEN (interaction exists in window)
3. getMatrix — A vs C cell is AMBER (SENT recommendation exists)
4. getMatrix — B vs C cell is GAP (no interaction, no recommendation)
5. getMatrix — diagonal (A vs A) is SELF
6. getMatrix — matrix is symmetric: cells[1][2].state === cells[2][1].state
7. getMatrix — windowDays filter: if A-B interaction is 200 days ago and window is 90, cell should be GAP not GREEN
8. getMemberCoverage — returns correct totalMembers, membersMet, coveragePct
9. getMemberCoverage — handles member with zero interactions gracefully (coveragePct = 0)

Run: npm test -- --testPathPattern=matrixService
Fix all failures.
```

---

### FIX-P08 · Matrix Bug Fix

```
Check the matrix logic:
1. Verify matrix symmetry: cells[i][j] and cells[j][i] must always have the same state. Write a loop in the test that checks every non-diagonal cell.
2. Verify that when a pair has both an interaction AND an open SENT recommendation, GREEN takes priority over AMBER
3. Check that the windowDays calculation uses interaction_date correctly (date-only comparison, not datetime)
4. Verify the Excel export: open the downloaded file and check that cell background colors are correct (green = #C6EFCE, amber = #FFEB9C, white = white)
5. Test with a chapter that has 1 member — should return a 1×1 matrix with just SELF

Fix all issues.
```

---

## PHASE 9 — MOD-04 FRONTEND

---

### P09-01 · MatrixGrid Component (complete)

```
Create src/components/matrix/MatrixGrid.tsx as a 'use client' component.

Full implementation:

Props: { chapterId: string }

State:
- windowDays: 30 | 90 | 180 (default 180)
- selectedCell: { ri: number; ci: number } | null
- selectedMember: string | null (member_id for coverage panel)

Data fetching: useQuery from @tanstack/react-query
- Key: ['matrix', chapterId, windowDays]
- Fetch: GET /api/chapters/{chapterId}/matrix?windowDays={n}
- staleTime: 30 seconds
- Show skeleton loader while loading

Matrix rendering:
- Sticky first column (member names) and sticky first row (member names as headers)
- Use overflow-auto on container so large matrices scroll
- Each cell: 40×40px minimum
- Cell colors: GREEN = bg-green-100 border-green-400, AMBER = bg-amber-100 border-amber-400, GAP = bg-white, EXCLUDED = bg-gray-100, SELF = bg-gray-200
- Cell icons: GREEN = ✓ in green, AMBER = ⏳, GAP = empty, EXCLUDED = ✗
- Click on any non-SELF cell: set selectedCell to open PairActionDrawer
- Click on member name (row or column header): set selectedMember to open CoveragePanel

CoveragePanel (right drawer):
- Slides in from right
- Shows: Total Members, Met, Not Covered, Coverage % (big number), Last 1-2-1 Date, Pending Recs
- "Recommend Now" button for each uncovered pair (calls POST .../recommendations/manual)
- Close button

PairActionDrawer (bottom sheet on mobile, right drawer on desktop):
- For GREEN: shows last 1-2-1 date, "Log New 1-2-1" button
- For AMBER: shows "Sent on [date]", "Mark as Complete" button, "Resend" button  
- For GAP: shows "Recommend this pair now" button, "Exclude pair" button
- For EXCLUDED: shows "Reinstate" button

TimeWindowFilter: a segmented control (30d / 90d / 180d)

Also create src/app/(dashboard)/chapter/matrix/page.tsx that renders MatrixGrid.
```

---

### P09-02 · ChapterMap Component (complete)

```
Complete the implementation of src/components/map/ChapterMap.tsx.

Full implementation as a 'use client' component:

1. Load map member pins from GET /api/chapters/{chapterId}/map/members
2. Show CategoryFilter dropdown that filters pins by biz_category
3. Initialise Google Maps centered on chapter office location (from chapter settings, fallback to India center)
4. Render pins for each member with geocode_status=RESOLVED
5. Members with no coordinates: show in a sidebar list below the map ("Members not on map yet")
6. On pin click: fetch /api/.../map/member/{id} and show InfoWindow with:
   - Member name (bold)
   - Business category (gray)
   - One-line summary
   - WhatsApp button: opens wa.me/{number} in new tab (only if shareable)
   - "Request 1-2-1" button: calls POST .../recommendations/manual with this member
7. Show member count: "X members on map, Y not yet geocoded"

Also add an offline-aware message: if navigator.onLine is false, show banner "Map requires connectivity — showing cached tiles only"

Create src/app/(dashboard)/chapter/map/page.tsx that renders ChapterMap.
```

---

### P09-03 · Recommendation Pipeline Page

```
Create src/app/(dashboard)/chapter/recommendations/page.tsx:

Use Server Component for initial data load.

Section 1 — "This Week's Recommendations" (top cards):
- Card: Total Sent | Completed | Expired | Pending
- Fetched server-side from RecommendationService

Section 2 — Recommendation Table (Client Component: RecommendationTable.tsx):
- Columns: Members (A and B names), Status badge, Sent Date, Completed Date, Actions
- Status filter tabs: All | Sent | Completed | Expired | Excluded
- Action buttons per row:
  * SENT: "Mark Complete" → opens date picker modal → calls /complete
  * SENT: "Exclude" → prompt for reason → calls /exclude
  * EXCLUDED: "Reinstate" → calls /reinstate
  * GAP (manual create): done from matrix

Section 3 — Run New Cycle button (ADMIN/LT only):
- "Run Recommendation Cycle" button
- Shows last run time and status
- Opens confirmation modal before running
- Shows progress: "Evaluating X pairs..." then "Done — X messages sent"
- Polls GET .../runs/{runId} every 2 seconds until status=COMPLETED

Section 4 — Recent Runs (collapsed accordion):
- Last 5 runs with trigger_type, started_at, status, pairs_sent

Create src/app/(dashboard)/chapter/recommendations/page.tsx and all sub-components.
```

---

### P09-04 · InstallPrompt Component (complete)

```
Complete the implementation of src/components/ui/InstallPrompt.tsx:

'use client' component:

1. Listen for 'beforeinstallprompt' event
2. Check localStorage for 'pwa-install-dismissed' key — if set and less than 7 days ago: don't show
3. Show a bottom sheet with:
   - BNI logo + "Install BNI Connect"
   - Subtitle: "Add to home screen for quick access to member directory and matrix"
   - Two buttons: "Install App" (calls deferredPrompt.prompt()) and "Not Now" (sets localStorage key)
   - On iOS: since iOS doesn't fire beforeinstallprompt, detect iOS userAgent and instead show:
     "Tap the Share button then 'Add to Home Screen' to install"
4. Show only on mobile (use useMediaQuery or window.innerWidth check)
5. After successful install (outcome='accepted'): hide permanently (set localStorage)

Also complete src/app/layout.tsx to include InstallPrompt at the end of the body.
```

---

### TEST-P09 · MOD-04 Frontend E2E Tests

```
Create tests/e2e/matrix.spec.ts using Playwright:

Setup: Seed test data — 4 members, 2 interactions, 1 SENT recommendation.

Tests:
1. Matrix page loads without errors
2. Matrix cells render with correct colors (check computed background-color CSS)
3. Clicking a GREEN cell opens the PairActionDrawer with "Log New 1-2-1" button
4. Clicking a GAP cell shows "Recommend this pair now" button
5. Clicking a member name header opens the CoveragePanel with coverage metrics
6. Time window filter changes the matrix display (switch from 180d to 30d — green cell should become gap if interaction was 60 days ago)
7. "Mark Complete" on an AMBER rec: opens date picker, submits, cell turns GREEN

Create tests/e2e/map.spec.ts:
1. Map page renders Google Maps embed
2. Category filter shows/hides pins
3. Clicking a pin opens InfoWindow with member name
4. Members without coordinates appear in the sidebar list

Create tests/e2e/recommendations.spec.ts:
1. Recommendation pipeline page shows correct summary cards
2. Status filter tabs work
3. "Run Recommendation Cycle" button shows confirmation, then run status

Run: npx playwright test
Fix all failures.
```

---

### FIX-P09 · MOD-04 Frontend Bug Fix

```
Test the complete MOD-04 UI flow:

1. Open Matrix page — does it load within 2 seconds for a 10-member chapter?
2. Is the matrix symmetric on screen? Click A→B and B→A cells — do they both show the same state?
3. On mobile (DevTools): does the matrix overflow-scroll work? Can you scroll both horizontally and vertically?
4. Does the Coverage Panel show the correct coverage % number?
5. Open the Map page — do all members with coordinates show pins?
6. Does clicking "Request 1-2-1" from the map pin InfoWindow work?
7. On the Recommendations page — does the run cycle poll correctly until completion?
8. Does the InstallPrompt appear on mobile and correctly hide after "Not Now"?
9. Check browser console for React errors — fix all
10. Run Lighthouse PWA audit (DevTools → Lighthouse → PWA): fix any failures

Fix all issues found.
```

---

## PHASE 10 — BACKGROUND JOBS & CUSTOM SERVER

---

### P10-01 · Custom Server (server.js)

```
Create server.js in the project root:

const { createServer } = require('http');
const { parse } = require('url');
const next = require('next');

const dev = process.env.NODE_ENV !== 'production';
const app = next({ dev });
const handle = app.getRequestHandler();

app.prepare().then(async () => {
  // Import scheduler after Next.js is ready (TypeScript compiled to JS)
  const { startScheduler } = require('./.next/server/jobs/scheduler');
  
  await startScheduler();
  console.log('[Scheduler] All cron jobs started');
  
  createServer((req, res) => {
    const parsedUrl = parse(req.url, true);
    handle(req, res, parsedUrl);
  }).listen(process.env.PORT || 3000, (err) => {
    if (err) throw err;
    console.log(`> Ready on http://localhost:${process.env.PORT || 3000}`);
  });
}).catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});

Also update package.json scripts:
  "dev": "node server.js"  — wait, this doesn't support hot reload
  Actually: "dev": "next dev",  (keep Next.js dev server for development)
  "start": "node server.js"  (use custom server in production only)
  "build": "next build"

Explain: In development, cron jobs don't need to run. In production, 'npm start' uses server.js.

Create ecosystem.config.js for PM2:
module.exports = {
  apps: [{
    name: 'bni-platform',
    script: 'server.js',
    instances: 1,
    exec_mode: 'fork',
    env_production: {
      NODE_ENV: 'production',
      PORT: 3000,
    },
    log_file: '/var/log/bni/combined.log',
    error_file: '/var/log/bni/error.log',
    time: true,
    max_restarts: 10,
    restart_delay: 5000,
  }]
};
```

---

### P10-02 · Background Jobs

```
Create all background job files:

src/jobs/PostMeetingJob.ts:
export class PostMeetingJob {
  static async run(): Promise<void>
  1. Load all chapters from DB
  2. For each chapter:
     a) Get current time in chapter.timezone using date-fns (install date-fns-tz: npm install date-fns-tz)
     b) Calculate meeting end time: meeting_start_time + meeting_duration_mins
     c) Calculate trigger time: meeting_end + post_meeting_delay_mins
     d) Check if chapter.meeting_day matches today in chapter timezone
     e) Check if current time is within a 5-minute window of trigger time (to handle the 5-min cron frequency)
     f) Check that a run of type POST_MEETING doesn't already exist for today
     g) If all checks pass: call RecommendationService.runRecommendationCycle('POST_MEETING')
  3. Catch and log errors per chapter — don't let one chapter failure stop others

src/jobs/WeeklyRecJob.ts:
export class WeeklyRecJob {
  static async run(): Promise<void>
  — For each chapter: call RecommendationService.runRecommendationCycle('SCHEDULED')
  — Catch and log errors per chapter

src/jobs/ExpireRecsJob.ts:
export class ExpireRecsJob {
  static async run(): Promise<void>
  — For each chapter: call RecommendationService.expireStaleRecommendations(chapterId)
  — Log count of expired recs

src/jobs/GeocodingRetryJob.ts:
export class GeocodingRetryJob {
  static async run(): Promise<void>
  — Call GeocodingService.retryPending()
  — Log stats

src/jobs/WeeklyEmailJob.ts:
export class WeeklyEmailJob {
  static async run(): Promise<void>
  — For each chapter that has LT members with email addresses (email is now required for all members):
    a) Compute weekly stats: recs sent this week, completed this week, matrix coverage change
    b) Build plain HTML email
    c) Send via nodemailer using SMTP settings from env
  — Log result

Add to .env.local:
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password

src/jobs/scheduler.ts:
export async function startScheduler(): Promise<void>
— Register all 5 cron jobs with node-cron as specified in LLD
— Add error handling wrapper around each job
— Log job start and completion
```

---

### TEST-P10 · Background Jobs Tests

```
Create src/__tests__/jobs.test.ts:

Mock all external calls (WhatsApp, Google Maps, nodemailer).

Tests for PostMeetingJob:
1. Run() does nothing if today is not a meeting day for any chapter
2. Run() triggers recommendation cycle if it is meeting day and trigger time has elapsed
3. Run() does NOT trigger if a POST_MEETING run already exists for today
4. Run() processes multiple chapters independently (one error doesn't stop others)

Tests for ExpireRecsJob:
1. Expires SENT recommendations older than rec_expiry_days
2. Does not expire COMPLETED recommendations
3. Does not expire QUEUED recommendations

Tests for WeeklyEmailJob:
1. Sends email to LT members with email addresses
2. Does not fail if no LT member has an email

Run: npm test -- --testPathPattern=jobs
Fix all failures.
```

---

### FIX-P10 · Jobs Bug Fix

```
Check the background jobs:
1. Test PostMeetingJob timezone logic carefully — create a chapter with timezone 'Asia/Kolkata' and verify the trigger time calculation is correct
2. Check that all jobs log their start time and completion time — review log output when running them manually
3. Manually invoke each job via a temporary test route (create GET /api/admin/jobs/run/[jobName] for testing only — remember to remove or secure this before production)
4. Verify the scheduler doesn't run in development (next dev mode)
5. Check that a job crash doesn't take down the entire Next.js server

Fix all issues found.
```

---

## PHASE 11 — LEADERSHIP DASHBOARD

---

### P11-01 · Dashboard Home

```
Create src/app/(dashboard)/page.tsx — the main leadership dashboard (redirect non-LT/ADMIN members to /chapter/members instead).

This is a Server Component that fetches all summary data directly via services.

Layout: 2-column grid on desktop, single column on mobile.

Card 1 — "This Week's 1-2-1 Activity":
- Recommendations sent this week
- Completed this week  
- Matrix coverage % (current 180-day window)
- "View Matrix" link

Card 2 — "Members Needing Attention" (Low Coverage):
- Top 5 members with lowest coverage % (< 30%)
- Name, Coverage %, Last 1-2-1 Date
- "Recommend Now" quick action

Card 3 — "Recent Recommendation Runs":
- Last 3 runs: trigger type, date, pairs sent, status
- "Run Now" button

Card 4 — "Geocoding Status":
- X members mapped / Y pending / Z failed
- "View map" link

Card 5 — "Open Recommendations":
- Count of SENT recs not yet completed
- Count of recs expiring in next 7 days (warning)

All cards must work on mobile (full width, stacked).
```

---

### TEST-P11 · Dashboard Tests

```
Create tests/e2e/dashboard.spec.ts:

1. Dashboard page loads for LT/ADMIN user (no redirect)
2. Non-LT member is redirected to /chapter/members
3. "Members Needing Attention" shows members with lowest coverage
4. "This Week's Activity" card shows correct count
5. "Run Now" button on dashboard triggers recommendation cycle

Run: npx playwright test tests/e2e/dashboard.spec.ts
Fix failures.
```

---

### FIX-P11 · Dashboard Bug Fix

```
Review the dashboard:
1. Check all stats are correct — cross-verify with direct DB queries
2. Ensure the dashboard loads in under 3 seconds (use browser DevTools Network tab)
3. Check mobile layout — all 5 cards should stack cleanly without horizontal overflow
4. Verify that non-ADMIN/LT users cannot access the dashboard (middleware redirects)

Fix all issues.
```

---

## PHASE 12 — END-TO-END INTEGRATION TESTING

---

### P12-01 · Full Integration Test Suite

```
Create tests/e2e/full-flow.spec.ts — a complete end-to-end test of the entire BNI platform workflow:

Scenario: Complete BNI Chapter Weekly Cycle

Step 1 — Login:
- Navigate to /login
- Enter WhatsApp number
- Enter OTP (use a test OTP injection endpoint for testing)
- Verify redirect to dashboard

Step 2 — Create two members (as ADMIN):
- Navigate to /chapter/members/new
- Create Member A: Ravi Shah, +91 98765 00001, Financial Advisor, "Expert in investment planning", Office: "Navrangpura, Ahmedabad"
- Create Member B: Priya Mehta, +91 98765 00002, HR Consultant, "Helping businesses find the right people", Office: "Satellite, Ahmedabad"
- Verify both appear in member list

Step 3 — Check Matrix:
- Navigate to /chapter/matrix
- Verify A and B show as GAP

Step 4 — Trigger Recommendation Cycle:
- Navigate to /chapter/recommendations
- Click "Run Recommendation Cycle"
- Wait for completion
- Verify a recommendation is created for A and B (status=SENT... will be QUEUED since WhatsApp is stubbed)

Step 5 — Simulate WhatsApp Reply:
- POST to /api/webhooks/whatsapp with a mock DONE payload from Member A's WhatsApp number
- Verify recommendation becomes COMPLETED
- Verify member_interaction is created

Step 6 — Check Matrix Again:
- Navigate to /chapter/matrix
- Verify A and B cell is now GREEN

Step 7 — Coverage Panel:
- Click Member A's name in matrix header
- Verify coverage panel shows 1 member met

Step 8 — Map Check:
- Navigate to /chapter/map
- Verify both members appear (or in the "not yet mapped" list if geocoding is pending)

Create a test data factory in tests/helpers/factory.ts with helper functions to create members, chapters, interactions quickly.

Run: npx playwright test tests/e2e/full-flow.spec.ts --headed
Fix all failures.
```

---

### P12-02 · Performance + PWA Audit

```
Run these audits and fix issues found:

1. Lighthouse PWA Audit:
   - npm run build && npm start (run production build)
   - Open Chrome DevTools → Lighthouse → PWA + Performance + Accessibility
   - Target scores: PWA: 100, Performance: > 80, Accessibility: > 90
   - Fix any PWA failures (manifest, service worker, HTTPS in production note)

2. Check service worker is generated:
   - After npm run build, verify public/sw.js exists
   - Verify public/workbox-*.js exists
   - Test offline fallback: run production build, open in browser, go offline (DevTools), reload a non-cached page — you should see offline.html

3. Performance checks:
   - Member list page: measure TTFB (Time to First Byte) — should be < 500ms (Server Component)
   - Matrix page: measure time to full render for 10-member chapter — should be < 2 seconds
   - First load JS bundle: check in Network tab — aim for < 300KB gzipped for initial load

4. Mobile responsiveness:
   - Test every page in DevTools device mode (iPhone SE, iPhone 14, Pixel 7)
   - Fix any horizontal overflow, text clipping, or touch target issues (min 44px touch targets)

Report findings and fix all critical issues.
```

---

### P12-03 · Security Hardening

```
Run these security checks and fix all issues:

1. Check that no GOOGLE_MAPS_SERVER_KEY appears anywhere in client-side bundle:
   - npm run build
   - Search .next/static/ folder: grep -r "GOOGLE_MAPS_SERVER_KEY" .next/static/
   - Must return 0 results

2. Check all API routes require authentication:
   - Write a test that calls every API endpoint without a token and verifies 401 response
   - Only /api/auth/* and /api/webhooks/whatsapp should be exempt

3. Check that encrypted PII is never returned in API responses:
   - Inspect the JSON response of GET /api/.../members — verify no 'mobile_enc' or 'whatsapp_enc' fields appear

4. Webhook security:
   - Test the WhatsApp webhook with a wrong HMAC signature — verify 401
   - Test with correct signature — verify 200

5. JWT security:
   - Verify access tokens expire after 15 minutes (adjust system time in test)
   - Verify refresh tokens are rotated (old one rejected after refresh)

6. Add security headers to Nginx config (we'll use this in deployment):
   Strict-Transport-Security, X-Content-Type-Options, X-Frame-Options, Referrer-Policy, Content-Security-Policy

Fix all security issues found.
```

---

## PHASE 13 — VPC DEPLOYMENT

---

### P13-01 · Production Environment Prep

```
Create a deployment checklist and all required configuration files. This is for deploying to a VPS/VPC running Ubuntu 22.04 LTS (no Docker).

Create a file called DEPLOYMENT.md in the project root with complete step-by-step instructions. Include:

Section 1 — Server Setup (run once on fresh Ubuntu 22.04):
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 20 (via NodeSource)
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Verify
node -v  # should be 20.x
npm -v

# Install MySQL 8.0
sudo apt install -y mysql-server
sudo mysql_secure_installation

# Create database and user
sudo mysql -u root -p <<EOF
CREATE DATABASE bnidb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'bni_user'@'localhost' IDENTIFIED BY 'STRONG_PASSWORD_HERE';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, INDEX, ALTER ON bnidb.* TO 'bni_user'@'localhost';
GRANT INSERT, SELECT ON bnidb.audit_logs TO 'bni_user'@'localhost';
FLUSH PRIVILEGES;
EOF

# Install PM2 globally
sudo npm install -g pm2

# Install Nginx
sudo apt install -y nginx

# Set up log directory
sudo mkdir -p /var/log/bni
sudo chown $USER:$USER /var/log/bni

Section 2 — App Deployment (run on each deploy):
# Clone or pull the repository
cd /var/www
sudo mkdir bni-platform
sudo chown $USER:$USER bni-platform
git clone https://github.com/YOUR_REPO/bni-platform.git bni-platform
cd bni-platform

# Install dependencies
npm ci --production=false

# Create .env.production (copy from .env.example and fill in real values)
cp .env.example .env.production
nano .env.production  # fill in all values

# Run database migrations
NODE_ENV=production npx prisma migrate deploy

# Run seed (first deploy only)
NODE_ENV=production npx prisma db seed

# Build the app
NODE_ENV=production npm run build

# Start with PM2
pm2 start ecosystem.config.js --env production
pm2 save
pm2 startup  # follow the instructions to auto-start on reboot

Section 3 — Nginx Configuration:
# Create /etc/nginx/sites-available/bni-platform
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com www.your-domain.com;

    ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;

    # Security headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Content-Type-Options nosniff;
    add_header X-Frame-Options DENY;
    add_header Referrer-Policy strict-origin-when-cross-origin;

    # PWA files — serve directly from Next.js public folder
    location /manifest.json { proxy_pass http://localhost:3000; }
    location /sw.js {
        proxy_pass http://localhost:3000;
        add_header Cache-Control "no-cache";  # SW must never be cached
    }
    location /offline.html { proxy_pass http://localhost:3000; }
    location /workbox- { proxy_pass http://localhost:3000; }

    # All other requests
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}

# Enable the site
sudo ln -s /etc/nginx/sites-available/bni-platform /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx

Section 4 — SSL with Let's Encrypt:
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com -d www.your-domain.com
# certbot auto-renews; verify with: sudo certbot renew --dry-run

Section 5 — Firewall:
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
sudo ufw enable

Section 6 — MySQL Grant Fix for audit_logs (important):
After the first migration, connect to MySQL and explicitly revoke UPDATE/DELETE on audit_logs:
sudo mysql -u root -p bnidb <<EOF
REVOKE UPDATE, DELETE ON bnidb.audit_logs FROM 'bni_user'@'localhost';
FLUSH PRIVILEGES;
EOF
```

---

### P13-02 · Deploy Script

```
Create deploy.sh in the project root — a one-command deployment script for subsequent deployments (after the first setup):

#!/bin/bash
set -e  # exit on any error

echo "🚀 Starting BNI Platform Deployment"

# Pull latest code
echo "📦 Pulling latest code..."
git pull origin main

# Install dependencies
echo "📦 Installing dependencies..."
npm ci --production=false

# Run migrations
echo "🗄️ Running database migrations..."
NODE_ENV=production npx prisma migrate deploy

# Build
echo "🏗️ Building Next.js app..."
NODE_ENV=production npm run build

# Reload PM2 (zero-downtime)
echo "♻️ Reloading application..."
pm2 reload bni-platform --update-env

echo "✅ Deployment complete!"
pm2 status

Make it executable: chmod +x deploy.sh

Also create health-check.sh:
#!/bin/bash
# Quick health check — run after deployment
curl -f http://localhost:3000/api/health || echo "HEALTH CHECK FAILED"
pm2 status bni-platform
mysql -u bni_user -p bnidb -e "SELECT COUNT(*) as members FROM members WHERE status='ACTIVE';"

Create the health check API route:
src/app/api/health/route.ts:
- GET — no auth required
- Returns: { status: 'ok', timestamp: ISO string, db: 'connected' | 'error' }
- Tests DB connection by running: prisma.$queryRaw`SELECT 1`
- Returns 200 if healthy, 503 if DB is down
```

---

### P13-03 · Production Environment Variables

```
Create a .env.production.example file (safe to commit — no real values) that lists every variable needed in production and what to set them to.

Also create a validation checklist PRODUCTION_CHECKLIST.md:

Pre-Deployment Checklist:
[ ] NODE_ENV is set to 'production'
[ ] DATABASE_URL points to production MySQL (not localhost)
[ ] JWT_SECRET is a 64-character random hex string (not the dev placeholder)
[ ] REFRESH_TOKEN_SECRET is different from JWT_SECRET
[ ] ENCRYPTION_KEY is a 64-character hex string (NEVER change this after first use — it will make all encrypted data unreadable)
[ ] HASH_PEPPER is set (NEVER change this after first use)
[ ] WHATSAPP_PHONE_NUMBER_ID is set (15-digit number from Meta dashboard)
[ ] WHATSAPP_BUSINESS_ACCOUNT_ID is set
[ ] WHATSAPP_API_TOKEN is the permanent System User Token from Meta Business Settings
[ ] WHATSAPP_VERIFY_TOKEN matches the value entered in Meta webhook configuration
[ ] bni_121_introduction template is approved by Meta (status: APPROVED) — only template needed
[ ] WHATSAPP_TEMPLATE_NAME env var matches the approved template name exactly
[ ] At least one ADMIN member has email_hash set and password_hash set (can log in)
[ ] Default admin password "BNI@2026!" has been changed on first login
[ ] All members have been created with email addresses by Admin
[ ] GOOGLE_MAPS_SERVER_KEY has IP restriction set to the server's static IP
[ ] NEXT_PUBLIC_GOOGLE_MAPS_KEY has HTTP Referrer restriction to the production domain
[ ] NEXT_PUBLIC_APP_URL is the production domain with https://
[ ] SMTP credentials are set for weekly email reports
[ ] Domain DNS A record points to the server IP
[ ] SSL certificate is issued by Let's Encrypt
[ ] Nginx is configured and running
[ ] PM2 is configured to auto-start on reboot (pm2 startup && pm2 save)
[ ] MySQL audit_logs UPDATE/DELETE privileges are revoked for app_user
[ ] Firewall allows only SSH, HTTP, HTTPS
[ ] /var/log/bni/ directory exists and is writable by the app user
[ ] npm run build completes with 0 errors
[ ] Health check passes: curl https://your-domain.com/api/health returns {"status":"ok"}
[ ] PWA: open the domain on mobile Chrome — Install option appears
[ ] PWA: install the app — verify it opens in standalone mode
[ ] WhatsApp webhook URL is configured in Meta App Dashboard → WhatsApp → Configuration:
    Callback URL: https://your-domain.com/api/webhooks/whatsapp
    Verify Token: (your WHATSAPP_VERIFY_TOKEN value)
    Subscribed fields: messages ✓
[ ] Meta webhook GET verification has been triggered and passed (Meta shows "Verified" status)
[ ] Test OTP login works end-to-end with a real WhatsApp number
```

---

### TEST-P13 · Deployment Verification

```
After deploying to VPC, run these verification steps:

1. Health check:
   curl https://your-domain.com/api/health
   Expected: {"status":"ok","db":"connected"}

2. PWA verification:
   - Open the domain on a real Android phone in Chrome
   - Verify the install prompt appears
   - Install the app and verify it opens in standalone mode (no browser URL bar)
   - Go offline and verify the offline page shows for uncached routes

3. WhatsApp test:
   a) Verify webhook is configured in Meta App Dashboard (should show "Verified")
   b) Send GET to https://your-domain.com/api/webhooks/whatsapp?hub.mode=subscribe&hub.verify_token=WRONG_TOKEN
      — Must return 403
   c) Test login: POST to /api/auth/login with admin email + password
      — Verify you receive an access token in the response body
      — Verify the refresh_token cookie is set (HttpOnly, check via curl -c cookie.txt)
   d) Test 1-2-1 recommendation message (the only WhatsApp template used):
      — Trigger a manual recommendation run from the dashboard
      — Verify the intro message arrives on the target member's WhatsApp
      — Verify template name matches bni_121_introduction

4. Database:
   ssh into server
   mysql -u bni_user -p bnidb -e "SHOW TABLES;"
   Verify all tables exist

5. Logs:
   pm2 logs bni-platform --lines 50
   Look for any startup errors

6. Cron jobs:
   Wait for the daily trigger time and verify from logs that the ExpireRecsJob ran
   Or: temporarily modify the cron to run every minute and watch the logs

7. Performance:
   Run curl -w "%{time_total}" https://your-domain.com/chapter/members
   Aim for < 1 second

Report any issues found.
```

---

### FIX-P13 · Production Bug Fix

```
If you encounter any of these common production issues, here is how to fix each:

Issue: "Cannot find module './.next/server/jobs/scheduler'" in server.js
Fix: The scheduler.ts must be compiled before server.js can require it. Ensure npm run build runs before npm start. In server.js, wrap the require in a try/catch and log a clear error message.

Issue: MySQL connection refused
Fix: Check DATABASE_URL is correct. Verify MySQL is running: sudo systemctl status mysql. Check that bni_user has correct host ('%' for remote, 'localhost' for local).

Issue: WhatsApp webhook not receiving messages
Fix:
  Step 1 — Verify the route is reachable:
    curl -X GET "https://your-domain.com/api/webhooks/whatsapp?hub.mode=subscribe&hub.verify_token=YOUR_TOKEN&hub.challenge=test123"
    Expected: plain text "test123"  (200 OK)
  Step 2 — Verify Meta webhook status:
    Go to Meta App Dashboard → WhatsApp → Configuration
    The webhook should show "Verified" with a green tick
    If not verified: click "Edit" and re-save — Meta will call the GET endpoint again
  Step 3 — Verify signature:
    curl -X POST https://your-domain.com/api/webhooks/whatsapp -d '{"test":1}'
    Expected: 401 (wrong/missing signature — but proves the route is reachable)
  Step 4 — Check phone number format in logs:
    Look for [Webhook] logs — confirm the 'from' number format is digits-only, no + prefix

Issue: Meta template rejected (sendTemplate returns 132001 error)
Fix:
  Error 132001 = Template does not exist or is not approved.
  Check: the template name in WHATSAPP_TEMPLATE_NAME exactly matches the approved template
  name in Meta Business Manager → Account Tools → Message Templates (case-sensitive).
  Approved templates show status "APPROVED" — PENDING or REJECTED will cause this error.

Issue: Meta returns 131030 error (Recipient phone number not in allowed list)
Fix:
  This happens during development when using a test phone number (not a production number).
  Meta test numbers can only send to a small list of verified recipient numbers.
  Add your test recipients in Meta App Dashboard → WhatsApp → API Setup → "To" section.
  In production with a real approved number, this restriction does not apply.

Issue: Google Maps not loading on production
Fix: Check NEXT_PUBLIC_GOOGLE_MAPS_KEY referrer restriction includes the production domain. Maps API billing account must be active. Check browser console for Maps API errors.

Issue: PWA not installing on iOS
Fix: iOS requires HTTPS (already done). Add all required apple-mobile-web-app meta tags. The install UX on iOS is manual (Share → Add to Home Screen) — verify your InstallPrompt shows iOS-specific instructions.

Issue: Service worker caching old code after deployment
Fix: next-pwa auto-versions the SW. But if users have the old SW cached, they need to wait for it to update. Add to Nginx: add_header Cache-Control "no-cache" for /sw.js specifically (already in the Nginx config above).

Issue: Prisma migration fails on production
Fix: Check DATABASE_URL is correct. Run: npx prisma migrate status to see pending migrations. If there's a conflict: DO NOT run migrate dev on production — only migrate deploy.

Apply all relevant fixes.
```

---

## QUICK REFERENCE

---

### COMMON COMMANDS

```bash
# Development
npm run dev              # Start dev server (Next.js hot reload)
npm test                 # Run Jest unit tests
npx playwright test      # Run E2E tests

# Database
npx prisma migrate dev --name "description"  # Create and apply migration (dev only)
npx prisma migrate deploy                     # Apply pending migrations (production)
npx prisma studio                             # Visual DB browser
npx prisma db seed                           # Run seed script
npx prisma generate                          # Regenerate Prisma client after schema change

# Build & Production
npm run build            # Build for production
npm start               # Start production server (with cron jobs)
npx tsc --noEmit        # Type check without building

# PM2 (on VPC)
pm2 start ecosystem.config.js --env production
pm2 status
pm2 logs bni-platform
pm2 reload bni-platform  # Zero-downtime reload
pm2 stop bni-platform
```

---

### PROMPT ORDER SUMMARY

| Phase | Prompts | What Gets Built |
|---|---|---|
| P00 | P00-01 → P00-06 | Project scaffold, PWA config, Tailwind |
| P01 | P01-01 → P01-02 | MySQL schema, migrations, seed |
| P02 | P02-01 → P02-04 | Encryption, JWT, OTP, auth middleware |
| P03 | P03-01 → P03-04 | MOD-01 backend: Member CRUD, audit, chapter settings |
| P04 | P04-01 → P04-05 | MOD-01 frontend: Member list, forms, settings |
| P05 | P05-01 → P05-03 | MOD-04 pairing engine, recommendation service |
| P06 | P06-01 → P06-03 | Meta Cloud API adapter, WhatsApp service (1-2-1 only — no OTP), webhook (GET verify + POST) |
| P07 | P07-01 → P07-03 | Google Maps adapter, geocoding, map API |
| P08 | P08-01 → P08-02 | Cross Engagement Matrix service and API |
| P09 | P09-01 → P09-04 | MOD-04 frontend: Matrix, Map, Pipeline, PWA Install |
| P10 | P10-01 → P10-02 | Custom server, background cron jobs |
| P11 | P11-01 | Leadership dashboard |
| P12 | P12-01 → P12-03 | Integration tests, Lighthouse, security audit |
| P13 | P13-01 → P13-03 | VPC deployment, Nginx, PM2, deploy script |

**Total prompts: 54 build prompts + 14 TEST prompts + 14 FIX prompts = 82 prompts**

---

### IF CLAUDE CODE GETS STUCK

Paste this into Claude Code:

```
Show me the current state of the project. List all files created so far, check for TypeScript errors with npx tsc --noEmit, and tell me what is missing or broken. Then suggest the next step.
```

---

*End of BNI Chapter Engagement Platform — Claude Code Prompt Playbook v1.0*
*Based on: SRS v1.0 Lean Edition + LLD v2 (Next.js 14 + MySQL 8 + PWA) + SRS PWA Addendum*
